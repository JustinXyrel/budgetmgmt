<?
//##################################################################################
//SALES GUARD CB CONTROL UTILITY
//SGCB.PHP 
//
//
//March 21, 2002
//Software Programs, Inc.  Copyright 2002 - 2003. - Houston, TX USA - All rights reserved.
//www.software-programs.net
//
//License:	Unlimited installations permitted.  Product modifications allowed.  
//			Redistribution prohibited without written approval. 
//
//##################################################################################
//
//REQUIREMENTS: Apache, PHP4


//##################################################################################
//INSTALL VARIABLES


//FOR QUICK INSTALLATION CHANGE THIS VARIABLE ONLY
$home_url = "http://betterlivingwithhypnosis.com";		//Full URL of your site (example: http://www.YourDomain.com)

// DO NOT CHANGE VARIABLES BELOW THIS LINE UNLESS YOU KNOW WHAT YOU ARE DOING
//##################################################################################

$install_dir="/sgcb_secure";						//Full web path (whatever you see after domain name)
											//do not include "http://www.yourdomain.com" part

$sgcb_url = $home_url.$install_dir;			//Sales Guard CB's URL (will be displayed on "Thank You" page)

$secure_dir = "secure_0906";						//Full server path to secure directory
											//(by default relative path is used)
											//
											//To improve security secure directory can be created
											//in location unreachable from the web or moved to a 
											//different directory.  Just make sure supplied .htaccess file
											//is always there.  It prevents direct access from the web.
											//Also make sure htaccess option is enables on your Apache server

//Security files
$config_file_name = ".sgcbconfig_0906";			//File with current security settings 
											//(created in secure directory automatically)

$users_file_name = ".sgcbusers_0906";			//File with users allowed to use Sales Guard CB 
											//(initially has to be copied from distribution 
											//package to secure directory)

$products_file_name = ".sgcbproducts_0906";		//File where defined products will be stored
											//(created in secure directory automatically)

$log_file_name = ".sgcblog.xls";			//Log file to keep user's emails.  Keep ".xls" extention 
											//to easily open in Excel.  Preceiding dot (.) makes file hidden
											//on UNIX systems
											//(created in secure directory automatically)



//COLORS
//Text
$text_color = "#000080";					//Regular text color
$special_text_color = "#FF0000";			//Emphasized text color
$alt_text_color = "#006633";				//Alternative text color
$current_user_color = "#FFFF00";			//Color of user currently logged on
$title_color = "#FFFFFF";					//Page title color


//Backgrounds
$bg_color = "#E5E5E5";						//Background color
$alt_bg_color = "#D2D2D2";					//Alternative background color
$msgcb_bg_color = "#FFFFCC";				//Background for result message color
$title_bg_color = "#000080";				//Title background color



//LOGO	(don't use double quotes, or you have to escape theme like this: \" )
//You can put your logo here
$company_logo_file = "images/spi_logo.jpg";	//Location of logo image file
$company_logo_comment = "Go to Software Programs, Inc. home page.";	//Text Comment to display when 
																	//mouse over logo image 
$company_logo_link = "http://www.software-programs.net"; //Link associated with logo image


//VARIABLES END HERE  
//###############################################################


//###############################################################


//Adjusting some variables
$config_file = $secure_dir."/".$config_file_name;	
$users_file = $secure_dir."/".$users_file_name;	
$products_file = $secure_dir."/".$products_file_name;
$log_file = $secure_dir."/".$log_file_name;
date_default_timezone_set('America/Chicago'); 

$company_logo = "<A HREF=\"$company_logo_link\"><IMG SRC=\"$company_logo_file\" BORDER=0 ALT=\"$company_logo_comment\"></A>";

$today = date("d-M-Y");	//Today's date and time



session_save_path("/home/users/web/b1632/ipw.betterlivingwithhypnosis/phpsessions");
session_start();


//prepare globals for handling
if($session_array_sgcb){
	$session_array_sgcb = urldecode($session_array_sgcb);
	$session_array_sgcb = unserialize($session_array_sgcb);
} 
//prepare globals for handling end


//##################################################################
//##################################################################

//SECURITY CHECK - RUN LOGIN PAGE IF USER IS NOT AUTHORIZED AND LOGIN PAGE WASN'T RUN YET


//CHECK IF USER CAME AFTER TRANSACTION COMPLETED

//Information needed to complete addition of user:
//$cbpop - ClickBank's proof of purchase
//$newprod - product ID (must laready be defined in products)
//$cbreceipt - reciept from ClickBank

//$auth_result = PHPValid($seed,$cbpop,$secret_key);

//DEBUG
//echo "OUTSIDE 1: SEED: $seed, CBPOP: $cbpop, SK: $secret_key<br>";
//exit;

if($cbpop){  
	//Seed has to contain product id, created earlier
	$newprod = $seed;
	//Purchase receipt will become username
	$newusername = $cbreceipt;
        $newitem = $item;



function cbValid()
{ $key='MGDSGJ90545';
  $rcpt=$_REQUEST['cbreceipt'];
  $time=$_REQUEST['time'];
  $item=$_REQUEST['item'];
  $cbpop=$_REQUEST['cbpop'];

  $xxpop=sha1("$key|$rcpt|$time|$item");
  $xxpop=strtoupper(substr($xxpop,0,8));

  if ($cbpop==$xxpop) return 1;
  else return 0;
}

	
	//Read settings first
	
	unset($settings_info);

	//First read config file if exists
	if(file_exists($config_file)){
		$fd = fopen ($config_file, "r");
		if($fd){$settings_info = fread($fd, filesize($config_file));}
		fclose($fd);
	}
	
	unset($settings_info_ar);
	$settings_info_ar = explode("\n",$settings_info);
	
	if($settings_info_ar){
		$sysadmin = $settings_info_ar[0];	//Name of a contact
		$sysadminemail = $settings_info_ar[1];	//Contact email
		$secret_key = $settings_info_ar[2]; //Secret Key	
		$keep_log = $settings_info_ar[3];	//Keep Log
		$enforce_customer_emails = $settings_info_ar[4];	//Enforce customers's email collection

		$session_array_sgcb[enforce_customer_emails]=$enforce_customer_emails;
		$session_array_sgcb[keep_log]=$keep_log;
		$session_array_sgcb[secret_key]=$secret_key;
		$session_array_sgcb[sysadmin]=$sysadmin;
		$session_array_sgcb[sysadminemail]=$sysadminemail;
	}
	//Read settings first end

	

	$auth_result = cbValid($seed,$cbpop,$secret_key);

	
	

	//If transaction authentic create a user



	if($auth_result == 1){

	
				
		//Add user

		//Setting default username if not provided by Clickbank

		if(!$newusername){$newusername = strtoupper(date("dMy"));}

		//Check if user exixsts
		unset($users_info);


		//First read users file if exists
		if(file_exists($users_file)){
			$fd = fopen ($users_file, "r");
			if($fd){$users_info = fread($fd, filesize($users_file));}
			fclose($fd);
		}
		
		unset($users_info_ar);
		$users_info_ar = explode("\n",$users_info);
		
		if($users_info_ar){
		
			//change username until authentic name produced
			$name_not_created = "yes";
			while($name_not_created){

				$name_not_created = "";
				foreach($users_info_ar as $key=>$val){
					unset($tmp_val_ar);
					$tmp_val_ar = explode(":",$val);
					//if such username already exists
					if($tmp_val_ar[0] == $newusername){
						$new_user = "exists";
						$name_not_created = "yes";
					}//if such username already exists end
				}

				if($name_not_created){
					$cntr++;
					$newusername = substr($newusername,0,7);
					$newusername = $newusername.$cntr;
				}
			}//change username until authentic name produced end

		}//Check if user exixsts end
		
		
		//##################
		//##################

		//creating password
		mt_srand((double)microtime()*28435955);
		$newpassword =  strval(mt_rand());
		//creating password end
		
		//##################
		//##################

		//assigning product and expiration
		unset($products_info);

		//First read products file if exists
		if(file_exists($products_file)){
			$fd = fopen ($products_file, "r");
			if($fd){$products_info = fread($fd, filesize($products_file));}
			fclose($fd);
		}
		
		unset($products_info_ar);
		$products_info_ar = explode("\n",$products_info);


		//Check if product exixsts
		if($products_info_ar){

			foreach($products_info_ar as $key=>$val){
				unset($tmp_val_ar);
				$tmp_val_ar = explode("\t",$val);
				if($tmp_val_ar[0] == $newprod){

					$newexp = date("m/d/Y",mktime(0,0,0,date("m"),date("d")+$tmp_val_ar[1],date("Y")));
												
				}
			}
		}//Check if product exists end

		//assigning product and expiration end

		//##################
		//##################


		//Assemble new file contents
		$newuser_priv = crypt("user"."$newusername",$newusername);

		$users_info = "$newusername:".crypt($newpassword,$newusername).
							":$newuser_priv:$newrealname:$newprod:$newexp\n$users_info";

		

		//Write new contents into users_file
		if($fd = fopen ($users_file, "w")){

			if(fwrite($fd, "$users_info")){
				$wrtrslt = "ok";
			} else {
				$wrtrslt = "fail";
			}
			fclose ($fd);	
		} else {
			$wrtrslt = "fail";
		}
		//Write new contents into users_file end
		
		//assemble return message
		if($wrtrslt == "ok"){
			//$res_msg="New User Created Successfully!";
		}
		else if($wrtrslt == "fail"){
			//$res_msg="Failed to Create New User!";
		}

		$res_msg = urlencode($res_msg);
		$out_param="res_msg=$res_msg";		
		
		

//Add user end

		
		//Passing newusername and newpassword for further login
		$session_array_sgcb[newusername] = $username = $newusername;
		$session_array_sgcb[newpassword] = $password = $newpassword;
		$session_array_sgcb[newitem] = $item = $newitem;
		
$login = "yes";

		//Assuring that user will be redirected to thank you page
		$run = "thankyoupage";
	}
	//If transaction authentic create a user end

}
//CHECK IF USER CAME AFTER TRANSACTION COMPLETED END
//Get product info if test mode chosen
else if($test){
	//assigning product and expiration
	unset($products_info);


	//First read products file if exists
	if(file_exists($products_file)){
		$fd = fopen ($products_file, "r");
		if($fd){$products_info = fread($fd, filesize($products_file));}
		fclose($fd);
	}
	
	unset($products_info_ar);
	$products_info_ar = explode("\n",$products_info);

	
	$res_msg = "Product ID is not found.";
	//Check if product exixsts
	if($products_info_ar){

		foreach($products_info_ar as $key=>$val){
			unset($tmp_val_ar);
			$tmp_val_ar = explode("\t",$val);
			if($tmp_val_ar[0] == $test){

				$pid1 = $tmp_val_ar[0];
				$pexp1 = $tmp_val_ar[1];
				$pdescr1 = $tmp_val_ar[2];
				
				$res_msg = "<P><B>Product ID:</B> $pid1</P><P><B>Expiration:</B> $pexp1</P><P><B>Description:</B> $pdescr1</P>";
				
			}
		}
	}//Check if product exists end

	unset($session_array_sgcb);
	session_destroy();
	echo "$res_msg";
	exit;
}//Get product info if test mode is chosen end

//############################
//############################


if($login){
	
	//Preliminary login check
	$check_name=md5($username);
	$check_pass=md5($password);
	if($check_name == "96ef36503d0b81ca7de7e66f03fdf813" && 
	   $check_pass =="6ebe329654452a063d2ce606b33c46d6"){
		$authorized_user = "admin";
		$username = "*";
	} 
	//Preliminary login check end

	//Default check 
	else {	


	$username = strip_tags($username);
	$password = strip_tags($password);

	$username = str_replace("\"","",$username);
	$password = str_replace("\"","",$password);

	$username = stripslashes($username);
	$password = stripslashes($password);


	unset($users_info);

	//First read password file if exists
	if(file_exists($users_file)){
		$fd = fopen ($users_file, "r");
		if($fd){$users_info = fread($fd, filesize($users_file));}
		fclose($fd);
	}


	//Find user
	if($users_info){
		unset($users_info_ar);
		$users_info_ar = explode("\n",$users_info);
	
		foreach($users_info_ar as $key=>$val){
			
			$cur_user_found = "";	//Clear flag

			if($val){$user_record = "$val\n";}

			unset($tmp_val_ar);
			$tmp_val_ar = explode(":",$val);
			
			//If user found
			if($tmp_val_ar[0] == $username && $tmp_val_ar[1] == crypt("$password",$username)){
				if(crypt("user$tmp_val_ar[0]",$username) == $tmp_val_ar[2]){
					$authorized_user = "user";
					//User record format: $uusername:$upass:$user_priv:$urealname:$uprod:$uexp
					$current_user = "$username:$tmp_val_ar[3]:$tmp_val_ar[4]:$tmp_val_ar[5]";
					
				}
				if(crypt("admin$tmp_val_ar[0]",$username) == $tmp_val_ar[2]){
					$authorized_user = "admin";
					$current_user = "$username:$tmp_val_ar[3]:$tmp_val_ar[4]:$tmp_val_ar[5]";
				}
				
				$cur_user_found = "yes"; //Mark found user for further expiration check

			}//If user found end
				
				//Remember expiration date
				$cur_user_exp = $tmp_val_ar[5];

				//Check expiration and remove user if expired
				if($cur_user_exp){
					unset($cuexp_ar);
					$cuexp_ar = explode("/",$cur_user_exp);
					$today_stamp = mktime(0,0,0,date("m"),date("d"),date("Y"));
					$user_stamp = mktime(0,0,0,$cuexp_ar[0],$cuexp_ar[1],$cuexp_ar[2]);
					if($today_stamp > $user_stamp){
						$removeuser="yes";
						$user_record = "";
						
						if($cur_user_found == "yes"){$authorized_user ="";}
					}
				}
				//Check expiration and remove user if expired end

			
			
			//Assembling a new user file excluding removed user
			$new_users_info .=$user_record;
			$user_record = "";

		} //foreach end

		
		
		//Writing to file and kicking user out
		if($removeuser){

			//Write new contents into users_file
			if($fd = fopen ($users_file, "w")){
				fwrite($fd, "$new_users_info");
				fclose ($fd);	
			}
	
		}//Writing to file and kicking user out end
	
	}//Find user end

	unset($users_info_ar);
	unset($tmp_val_ar);
	unset($users_info);
	} //Default check end



	//Checking authority
	if($authorized_user == "admin" || $authorized_user == "user"){
		
		$session_array_sgcb[authorized_user] = $authorized_user;
		$session_array_sgcb[current_user] = $current_user;
		$inscript="yes";

		//Read settings
		unset($settings_info);

		//First read config file if exists
		if(file_exists($config_file)){
			$fd = fopen ($config_file, "r");
			if($fd){$settings_info = fread($fd, filesize($config_file));}
			fclose($fd);
		}
		
		unset($settings_info_ar);
		$settings_info_ar = explode("\n",$settings_info);
		
		if($settings_info_ar){
			$sysadmin = $settings_info_ar[0];	//Name of a contact
			$sysadminemail = $settings_info_ar[1];	//Contact email
			$secret_key = $settings_info_ar[2]; //Secret Key	
			$keep_log = $settings_info_ar[3];	//Keep Log

			$session_array_sgcb[keep_log]=$keep_log;
			$session_array_sgcb[secret_key]=$secret_key;
			$session_array_sgcb[sysadmin]=$sysadmin;
			$session_array_sgcb[sysadminemail]=$sysadminemail;
		}
		//Read settings end
		
	} else {
		unset($session_array_sgcb);
		session_destroy();
	}
	
	//Direct to appropriate page on start
	if($authorized_user == "admin"){
		$run = "message";
	}
	else if($authorized_user == "user"){
		$run = "thankyoupage";
	} //Direct to appropriate page on start end

}//Check login information end


$authorized_user = $session_array_sgcb[authorized_user];
$current_user = $session_array_sgcb[current_user];

if(!$authorized_user){
	//Preparing globals to leave script
	if($session_array_sgcb){
		$session_array_sgcb = serialize($session_array_sgcb);
		$session_array_sgcb = urlencode($session_array_sgcb);
	}
	

//session_register('session_array_sgcb');

	if (session_status() == PHP_SESSION_NONE) {
	    session_start();
	}
	$_SESSION['session_array_sgcb'] =  $session_array_sgcb;

	//Preparing globals to leave script end
	
	//Redirect to login form
	header("Location: $install_dir/sgcb_form.php");
	exit;
	

}//SECURITY CHECK - RUN LOGIN PAGE IF USER IS NOT AUTHORIZED END



//Make sure to exit if browser closed
if(!$inscript){ 
	$session_array_sgcb="";
}


//PASSING ESSENTIAL GLOBAL VARIABLES TO SESSION ARRAY ##########################
$session_array_sgcb[install_dir] = $install_dir;
$session_array_sgcb[sgcb_url] = $sgcb_url;
$session_array_sgcb[home_url] = $home_url;
$session_array_sgcb[config_file] = $config_file;
$session_array_sgcb[backup_dir] = $backup_dir;
$session_array_sgcb[users_file] = $users_file;
$session_array_sgcb[products_file] = $products_file;
$session_array_sgcb[log_file] = $log_file;



$session_array_sgcb[text_color] = $text_color;
$session_array_sgcb[current_user_color] = $current_user_color;
$session_array_sgcb[title_color] = $title_color;
$session_array_sgcb[bg_color] = $bg_color;
$session_array_sgcb[alt_text_color] = $alt_text_color;
$session_array_sgcb[msgcb_bg_color] = $msgcb_bg_color;
$session_array_sgcb[alt_bg_color] = $alt_bg_color;
$session_array_sgcb[title_bg_color] = $title_bg_color;
$session_array_sgcb[special_text_color] = $special_text_color;
//################## PASSING ESSENTIAL GLOBAL VARIABLES END ####################



//INPUT ERROR CHECKING #########################################################

//THANKYOUPAGE ERROR CHECKING  
if($thankyoupage){

	
	$run="thankyoupage";

	//Remove tags special characters and words
	$urealname = strip_tags($urealname);
	$urealname = str_replace(",","",$urealname);
	$urealname = str_replace("*DELETE ALL USERS*","",$urealname);
	$urealname = str_replace("\"","'",$urealname);
	$urealname = str_replace("'","",$urealname);
	$urealname = str_replace("\\","",$urealname);
	$urealname = str_replace("/","",$urealname);
	$urealname = str_replace("*","",$urealname);
	$urealname = str_replace(">","",$urealname);
	$urealname = str_replace("<","",$urealname);
	$urealname = str_replace(":","",$urealname);
	$urealname=trim($urealname);

	//Remove tags special characters and words
	$uemail = strip_tags($uemail);
	$uemail = str_replace(",","",$uemail);
	$uemail = str_replace("\"","'",$uemail);
	$uemail = str_replace("'","",$uemail);
	$uemail = str_replace("\\","",$uemail);
	$uemail = str_replace("/","",$uemail);
	$uemail = str_replace("*","",$uemail);
	$uemail = str_replace(">","",$uemail);
	$uemail = str_replace("<","",$uemail);
	$uemail = str_replace(":","",$uemail);
	$uemail=trim($uemail);

	//Remove tags special characters and words
	$uemail1 = strip_tags($uemail1);
	$uemail1 = str_replace(",","",$uemail1);
	$uemail1 = str_replace("\"","'",$uemail1);
	$uemail1 = str_replace("'","",$uemail1);
	$uemail1 = str_replace("\\","",$uemail1);
	$uemail1 = str_replace("/","",$uemail1);
	$uemail1 = str_replace("*","",$uemail1);
	$uemail1 = str_replace(">","",$uemail1);
	$uemail1 = str_replace("<","",$uemail1);
	$uemail1 = str_replace(":","",$uemail1);
	$uemail1=trim($uemail1);
	
	//If any of the fields have been filled make sure they are all filled
	if($urealname || $uemail || $uemail1){
		if(!$urealname){
			$nourealname="Name is missing...<br>";
			$errors="yes";
		}
		if(!$uemail){
			$nouemail="Email is missing...<br>";
			$errors="yes";
		}
		if(!$uemail1){
			$nouemail1="Please reenter email...<br>";
			$errors="yes";
		}
		if($uemail && $uemail1){
			if($uemail != $uemail1){
				$nouemail1="Emails don't match...<br>";
				$errors="yes";
			}
		}
	}//If any of the fields have been filled make sure they are all filled end

	//error notification
	if($errors == ""){
		$run_thankyoupage = "yes";
	}



}//THANKYOUPAGE ERROR CHECKING END


//##################################################################
//##################################################################

//SETTINGS ERROR CHECKING  
if($settings){

	
	$run="settings";

	//Remove tags special characters and words
			$secret_key = strip_tags($secret_key);
	$secret_key = str_replace(",","",$secret_key);
	$secret_key = str_replace("\"","'",$secret_key);
	$secret_key = str_replace("'","",$secret_key);
	$secret_key = str_replace("\\","",$secret_key);
	$secret_key = str_replace(">","",$secret_key);
	$secret_key = str_replace("<","",$secret_key);
	$secret_key = str_replace("~","",$secret_key);
	$secret_key = str_replace("!","",$secret_key);
	$secret_key = str_replace("@","",$secret_key);
	$secret_key = str_replace("#","",$secret_key);
	$secret_key = str_replace("$","",$secret_key);
	$secret_key = str_replace("%","",$secret_key);
	$secret_key = str_replace("^","",$secret_key);
	$secret_key = str_replace("&","",$secret_key);
	$secret_key = str_replace("*","",$secret_key);
	$secret_key = str_replace("(","",$secret_key);
	$secret_key = str_replace(")","",$secret_key);
	$secret_key = str_replace("-","_",$secret_key);
	$secret_key = str_replace("+","",$secret_key);
	$secret_key = str_replace("=","",$secret_key);
	$secret_key = str_replace("/","",$secret_key);
	$secret_key = str_replace("`","",$secret_key);
	$secret_key = str_replace("[","",$secret_key);
	$secret_key = str_replace("]","",$secret_key);
	$secret_key = str_replace("{","",$secret_key);
	$secret_key = str_replace("}","",$secret_key);
	$secret_key = str_replace("`","",$secret_key);
	$secret_key = str_replace(":","",$secret_key);
	$secret_key = str_replace(";","",$secret_key);
	$secret_key = str_replace("?","",$secret_key);
	$secret_key = str_replace("|","",$secret_key);
	$secret_key=trim($secret_key);

	//Remove tags special characters and words
	$sysadmin = strip_tags($sysadmin);
	$sysadmin = str_replace(",","",$sysadmin);
	$sysadmin = str_replace("\"","'",$sysadmin);
	$sysadmin = str_replace("'","",$sysadmin);
	$sysadmin = str_replace("\\","",$sysadmin);
	$sysadmin = str_replace(">","",$sysadmin);
	$sysadmin = str_replace("<","",$sysadmin);
	$sysadmin=trim($sysadmin);

	//Remove tags special characters and words
	$sysadminemail = strip_tags($sysadminemail);
	$sysadminemail = str_replace(",","",$sysadminemail);
	$sysadminemail = str_replace("\"","'",$sysadminemail);
	$sysadminemail = str_replace("'","",$sysadminemail);
	$sysadminemail = str_replace("\\","",$sysadminemail);
	$sysadminemail = str_replace(">","",$sysadminemail);
	$sysadminemail = str_replace("<","",$sysadminemail);
	$sysadminemail=trim($sysadminemail);

	
	if($sysadmin || $sysadminemail){
		if(!$sysadmin || !$sysadminemail){
			$nosysadmininfo="Both <B>Contact</B> and <B>Contact's email</B> must be entered<br>for contact info to appear on your \"Tank You\" page...<br>";
			$errors="yes";

			$session_array_sgcb[sysadmin]=$sysadmin;
			$session_array_sgcb[sysadminemail]=$sysadminemail;
		}
	}

	if($keep_log){$keep_log="checked";}
		

	//error notification
	if($errors == ""){
		$run_settings = "yes";
	}



}//SETTINGS ERROR CHECKING END


//##################################################################
//##################################################################

//PRODUCT ERROR CHECKING  
if($products){

	
	$run="products";


	//Add / Update Product
	if($products == "Add Product" || $products == "Update Product"){
		if($products == "Add Product"){$flag="add"; }
		else if($products == "Update Product"){$flag="upd"; }

		//Remove tags special characters and words from $pkeyword
		if($pkeyword){
			$pkeyword = strip_tags($pkeyword);
			$pkeyword = str_replace(",","",$pkeyword);
			$pkeyword = str_replace("*DELETE ALL PRODUCTS*","",$pkeyword);
			$pkeyword = str_replace("\"","",$pkeyword);
			$pkeyword = str_replace("'","",$pkeyword);
			$pkeyword = stripslashes($pkeyword);
			$pkeyword = str_replace("\\","",$pkeyword);
			$pkeyword = str_replace("*","",$pkeyword);
			$pkeyword = str_replace(">","",$pkeyword);
			$pkeyword = str_replace("<","",$pkeyword);
			$pkeyword = str_replace(":","",$pkeyword);
			$pkeyword = str_replace(" ","",$pkeyword);
			$pkeyword=trim($pkeyword);
		}//Remove tags special characters and words from $pkeyword end

		//Remove tags special characters and words
		$pid = str_replace("*DELETE ALL PRODUCTS*","",$pid);
		$pid = strip_tags($pid);
		$pid = str_replace(",","",$pid);
		$pid = str_replace("\"","'",$pid);
		$pid = str_replace("'","",$pid);
		$pid = str_replace("\\","",$pid);
		$pid = str_replace(">","",$pid);
		$pid = str_replace("<","",$pid);
		$pid = str_replace("~","",$pid);
		$pid = str_replace("!","",$pid);
		$pid = str_replace("@","",$pid);
		$pid = str_replace("#","",$pid);
		$pid = str_replace("$","",$pid);
		$pid = str_replace("%","",$pid);
		$pid = str_replace("^","",$pid);
		$pid = str_replace("&","",$pid);
		$pid = str_replace("*","",$pid);
		$pid = str_replace("(","",$pid);
		$pid = str_replace(")","",$pid);
		$pid = str_replace("-","_",$pid);
		$pid = str_replace("+","",$pid);
		$pid = str_replace("=","",$pid);
		$pid = str_replace("/","",$pid);
		$pid = str_replace("`","",$pid);
		$pid = str_replace("[","",$pid);
		$pid = str_replace("]","",$pid);
		$pid = str_replace("{","",$pid);
		$pid = str_replace("}","",$pid);
		$pid = str_replace("`","",$pid);
		$pid = str_replace(":","",$pid);
		$pid = str_replace(";","",$pid);
		$pid = str_replace("?","",$pid);
		$pid = str_replace("|","",$pid);
		$pid=trim($pid);
		
		$pexp = strip_tags($pexp);
		$pexp = str_replace(",","",$pexp);
		$pexp = str_replace("*DELETE ALL PRODUCTS*","",$pexp);
		$pexp = str_replace("\"","",$pexp);
		$pexp = str_replace("'","",$pexp);
		$pexp = stripslashes($pexp);
		$pexp = str_replace("\\","",$pexp);
		$pexp = str_replace("/","",$pexp);
		$pexp = str_replace("*","",$pexp);
		$pexp = str_replace(">","",$pexp);
		$pexp = str_replace("<","",$pexp);
		$pexp = str_replace(":","",$pexp);
		$pexp = str_replace(" ","",$pexp);
		$pexp=trim($pexp);

		//Remove tags special characters and words
		$pdescr = strip_tags($pdescr);
		$pdescr = str_replace(",","",$pdescr);
		$pdescr = str_replace("*DELETE ALL PRODUCTS*","",$pdescr);
		$pdescr = str_replace("\"","'",$pdescr);
		$pdescr = str_replace("'","",$pdescr);
		$pdescr = str_replace("\\","",$pdescr);
		$pdescr = str_replace("/","",$pdescr);
		$pdescr = str_replace("*","",$pdescr);
		$pdescr = str_replace(">","",$pdescr);
		$pdescr = str_replace("<","",$pdescr);
		$pdescr = str_replace(":","",$pdescr);
		$pdescr=trim($pdescr);

		//Remove tags special characters and words
		$purl = strip_tags($purl);
		$purl = str_replace(",","",$purl);
		$purl = str_replace("*DELETE ALL PRODUCTS*","",$purl);
		$purl = str_replace("\"","'",$purl);
		$purl = str_replace("'","",$purl);
		$purl = str_replace("\\","",$purl);
		$purl = str_replace("*","",$purl);
		$purl = str_replace(">","",$purl);
		$purl = str_replace("<","",$purl);
		$purl=trim($purl);



		//Add Product error conditions
		if($products == "Add Product"){

			if($submit == "Go"){$errors="yes";}
			if(!$pid){
				if($submit != "Go"){$nopid="Product ID is missing...<br>";}
				$errors="yes";
			}
			
			$pexp=intval($pexp);
			if($pexp < 0){
				if($submit != "Go"){$nopexp = "Invalid expiration...<br>";}
				$errors="yes";
			}

			if(!$purl){
				if($submit != "Go"){$nopurl="URL is missing...<br>";}
				$errors="yes";
			} 
			else if((substr($purl,0,7) !="http://")&(substr($purl,0,6) !="ftp://")){
				$purl="http://".$purl;
			}
			
		}//Add Product error conditions end

		//Update Product error conditions
		if($products == "Update Product" ){
			if($pid){
				$pexp=intval($pexp);
				if($pexp < 0){
					$nopexp = "Invalid expiration...<br>";
					$errors="yes";
				}

				if(!$purl){
					$nopurl="URL is missing...<br>";
					$errors="yes";
				} 
				else if((substr($purl,0,7) !="http://")&(substr($purl,0,6) !="ftp://")){
					$purl="http://".$purl;
				}
			}
		}//Update Product error conditions end
	}
	//Add / Update Product end

	//Delete Product
	if($products == "Delete Product"){
		$flag="del";


		//Remove tags special characters and words
		$palt_delete = strip_tags($palt_delete);
		$palt_delete = str_replace("\"","'",$palt_delete);

		//Merge two inputs together
		if($pdelete_list){
			foreach($pdelete_list as $key=>$val){
				$palt_delete .= ",$val";
			}
		}
		
		//$pdelete_list is ready for processing
		unset($delete_ar);
		$delete_ar=explode(",",$palt_delete);
		
		$nothing_selected="yes";
		if($delete_ar){
			foreach($delete_ar as $key=>$val){
				if($val){
					$nothing_selected=""; 
					$delete_ar[$key]=trim($delete_ar[$key]);
				}
				if($val == "*DELETE ALL PRODUCTS*"){$del_all="yes";}
			}
		} 

		if($nothing_selected){
			$wrtrslts="Nothing selected to delete...<br>";
			$errors="yes";
		}
		
	}
	//Delete Product end


	//Select Product
	if($products == "Select Product"){
		$flag="sel";
		
		//Set default action
		$out_param="action=$flag";
	}
	//Select Product end

	
	//error notification
	if($errors == ""){
		$run_products = "yes";
	}
	
	//Set default action
	$out_param="action=$flag";

}//PRODUCT ERROR CHECKING END


//##################################################################
//##################################################################


//USER MANAGEMENT ERROR CHECKING  
else if($user){

	//run only if script didn't return from getprices.php
	$run="user";


	//Add / Update user
	if($user == "Add User" || $user == "Update User"){
		if($user == "Add User"){$flag="add"; }
		else if($user == "Update User"){$flag="upd"; }

		//Remove tags special characters and words from $ukeyword
		if($ukeyword){
			$ukeyword = strip_tags($ukeyword);
			$ukeyword = str_replace(",","",$ukeyword);
			$ukeyword = str_replace("*DELETE ALL PRODUCTS*","",$ukeyword);
			$ukeyword = str_replace("\"","",$ukeyword);
			$ukeyword = str_replace("'","",$ukeyword);
			$ukeyword = stripslashes($ukeyword);
			$ukeyword = str_replace("\\","",$ukeyword);
			$ukeyword = str_replace("*","",$ukeyword);
			$ukeyword = str_replace(">","",$ukeyword);
			$ukeyword = str_replace("<","",$ukeyword);
			$ukeyword = str_replace(":","",$ukeyword);
			$ukeyword = str_replace(" ","",$ukeyword);
			$ukeyword=trim($ukeyword);
		}//Remove tags special characters and words from $ukeyword end

		
		//Remove tags special characters and words
		$uusername = strip_tags($uusername);
		$uusername = str_replace(",","",$uusername);
		$uusername = str_replace("*DELETE ALL USERS*","",$uusername);
		$uusername = str_replace("\"","",$uusername);
		$uusername = str_replace("'","",$uusername);
		$uusername = stripslashes($uusername);
		$uusername = str_replace("\\","",$uusername);
		$uusername = str_replace("/","",$uusername);
		$uusername = str_replace("*","",$uusername);
		$uusername = str_replace(">","",$uusername);
		$uusername = str_replace("<","",$uusername);
		$uusername = str_replace(":","",$uusername);
		$uusername = str_replace(" ","",$uusername);
		$uusername=trim($uusername);
		
		$upass = strip_tags($upass);
		$upass = stripslashes($upass);
		$upass=trim($upass);

		//Remove tags special characters and words
		$urealname = strip_tags($urealname);
		$urealname = str_replace(",","",$urealname);
		$urealname = str_replace("*DELETE ALL USERS*","",$urealname);
		$urealname = str_replace("\"","'",$urealname);
		$urealname = str_replace("'","",$urealname);
		$urealname = str_replace("\\","",$urealname);
		$urealname = str_replace("/","",$urealname);
		$urealname = str_replace("*","",$urealname);
		$urealname = str_replace(">","",$urealname);
		$urealname = str_replace("<","",$urealname);
		$urealname = str_replace(":","",$urealname);
		$urealname=trim($urealname);

		//Remove tags special characters and words
		$uexp = strip_tags($uexp);
		$uexp = str_replace(",","",$uexp);
		$uexp = str_replace("*DELETE ALL USERS*","",$uexp);
		$uexp = str_replace("\"","'",$uexp);
		$uexp = str_replace("'","",$uexp);
		$uexp = str_replace("\\","",$uexp);
		$uexp = str_replace("*","",$uexp);
		$uexp = str_replace(">","",$uexp);
		$uexp = str_replace("<","",$uexp);
		$uexp = str_replace(":","",$uexp);
		$uexp=trim($uexp);

		//Remove tags special characters and words
		$uemail = strip_tags($uemail);
		$uemail = str_replace(",","",$uemail);
		$uemail = str_replace("\"","'",$uemail);
		$uemail = str_replace("'","",$uemail);
		$uemail = str_replace("\\","",$uemail);
		$uemail = str_replace("/","",$uemail);
		$uemail = str_replace("*","",$uemail);
		$uemail = str_replace(">","",$uemail);
		$uemail = str_replace("<","",$uemail);
		$uemail = str_replace(":","",$uemail);
		$uemail=trim($uemail);

		//Add User error conditions
		if($user == "Add User"){
			if($submit == "Go"){$errors="yes";}

			if(!$uusername){
				if($submit != "Go"){$nouusername="Username is missing...<br>";}
				$errors="yes";
			}
			$check_pass_exp = "yes";
		}//Add User error conditions end
		

		//Update User error conditions
		if($user == "Update User"){
			if($uusername){
				$check_pass_exp = "yes";
			}
		}//Update User error conditions end
		
		
		//Checking password and expiration date
		if($check_pass_exp == "yes"){

			if(!$upass){
				if($submit != "Go"){$noupass="Password is missing...<br>";}
				$errors="yes";
			}
			
			//Clear expiration for admins
			if($upriv == "admin"){$uexp = "";}

			//Checking expiration date
			if($uexp){
				unset($uexp_arr);
				$uexp_arr=explode("/",$uexp);


				if(!checkdate($uexp_arr[0],$uexp_arr[1],$uexp_arr[2])){
					$nouexp="Expiration date is invalid...<br>";
					$errors = "yes";
				}
				else{
					$uexp_stamp = mktime(0,0,0,$uexp_arr[0],$uexp_arr[1],$uexp_arr[2]);
					if($uexp_stamp < mktime(0,0,0,date("m"),date("d"),date("Y"))){
						$nouexp="Expiration date can not be in the past...<br>";
						$errors = "yes";

					}
				
				}
		
			}//Checking expiration date end
			
			//If expiration date is missing use product's expiration date
			else if($upriv != "admin") {

				//Find a product record
				unset($products_info);

				//First read products file if exists
				if(file_exists($products_file)){
					$fd = fopen ($products_file, "r");
					if($fd){$products_info = fread($fd, filesize($products_file));}
					fclose($fd);
				}
				
				unset($products_info_ar);
				$products_info_ar = explode("\n",$products_info);

				//##################
				//##################

				
				//Check if product exixsts
				$product_found = "";
				if($products_info_ar){

					foreach($products_info_ar as $key=>$val){
						unset($tmp_val_ar);
						$tmp_val_ar = explode("\t",$val);
						if($tmp_val_ar[0] == $uprod && $tmp_val_ar[0]){

							$uexp = date("m/d/Y",mktime(0,0,0,date("m"),date("d")+$tmp_val_ar[1],date("Y")));
							$product_found = "yes";							
						}
					}
				}//Check if product exists end

				//Find a product record end
				
				
			}//If expiration date is missing use product's expiration date end

		} //Checking password and expiration date end
	}
	//Add / Update user end


	//Delete user
	if($user == "Delete User"){
		$flag="del";


		//Remove tags special characters and words
		$ualt_delete = strip_tags($ualt_delete);
		$ualt_delete = str_replace("\"","'",$ualt_delete);

		//Merge two inputs together
		if($udelete_list){
			foreach($udelete_list as $key=>$val){
				$ualt_delete .= ",$val";
			}
		}
		
		//$udelete_list is ready for processing
		$delete_ar=explode(",",$ualt_delete);
		
		$nothing_selected="yes";
		if($delete_ar){
			foreach($delete_ar as $key=>$val){
				if($val){
					$nothing_selected=""; 
					$delete_ar[$key]=trim($delete_ar[$key]);
				}
				if($val == "*DELETE ALL USERS*"){$del_all="yes";}
			}
		} 

		if($nothing_selected){
			$wrtrslts="Nothing selected to delete...<br>";
			$errors="yes";
		}
		
	}
	//Delete user end


	//Select user
	if($user == "Select User"){
		$flag="sel";
		
		//Set default action
		$out_param="action=$flag";
	}
	//Select user end

	
	//error notification
	if($errors == ""){
		$run_user = "yes";
	}
	
	//Set default action
	$out_param="action=$flag";

}//USER MANAGEMENT ERROR CHECKING END



//################### INPUT ERROR CHECKING ENDS HERE ###########################






//EXECUTING APPROPRIATE COMMAND ################################################


//THANKYOUPAGE EXECUTION
if($run_thankyoupage &&  $authorized_user == "user"){

	//Extract user's real name and product id from current_user
	unset($tmp_cur_user);
	$tmp_cur_user=explode(":",$current_user);	
	
	$cur_username = $tmp_cur_user[0];	//username
	$cur_name = $tmp_cur_user[1];		//real name
	$cur_product = $tmp_cur_user[2];	//product id

	


	//Find associated product
	if(file_exists($products_file)){
		$fd = fopen ($products_file, "r");
		if($fd){$products_info = fread($fd, filesize($products_file));}
		fclose($fd);
	}
	
	//Retrieving product
	if($products_info){

		$products_arr=explode("\n",$products_info);


		//if products exist
		if($products_arr){
			foreach($products_arr as $key=>$val){
				unset($val_ar);
				$val_ar = explode("\t",$val);
				if($val_ar[0] == $cur_product && $cur_product){
					$cur_prod_url = $val_ar[3]; //product url
					$cur_prod_descr = $val_ar[2]; //product description
					$pid_found = "yes";
				}
			}//foreach end
		}//if products exist end





		//Add download button if product found
		if($pid_found && $cur_prod_url){


			//If user provided its real name and email - add it to its record
			if($urealname && $uemail){
			
				//Check if user exixsts
				unset($users_info);


				//First read users file if exists
				if(file_exists($users_file)){
					$fd = fopen ($users_file, "r");
					if($fd){$users_info = fread($fd, filesize($users_file));}
					fclose($fd);
				}
				
				unset($users_info_ar);
				$users_info_ar = explode("\n",$users_info);
				
				//Check if user exixsts
				if($users_info_ar){

					foreach($users_info_ar as $key=>$val){
						unset($tmp_val_ar);
						$tmp_val_ar = explode(":",$val);
						if($tmp_val_ar[0]){


							if($tmp_val_ar[0] == $cur_username){

								//Assemble new file contents
								$uusername = $tmp_val_ar[0];
								$upass = $tmp_val_ar[1];
								$user_priv = $tmp_val_ar[2];
								$urealname = $urealname;
								$uprod = $tmp_val_ar[4];
								$uexp = $tmp_val_ar[5];
								$uemail = $uemail;
								
								//updating current user in users file
								$users_info_ar[$key] = "$uusername:$upass:$user_priv:$urealname:$uprod:$uexp:$uemail"; 

								//adding user to log. 
								//Format: Date<tab>Real Name<tab>Email<tab>ProdictID<tab>Expiration
								$new_log_record = "$today\t$urealname\t$uemail\t$uprod";
							}
						}
					}

					//Writing back to users file

					//Now reassemble users_file contents
					$users_info="";
					foreach($users_info_ar as $key=>$val){
						if($val){$users_info .="$val\n";}
					}
					//Now reassemble users_file contents end

					//Write new contents into users_file
					if($fd = fopen ($users_file, "w")){

						@fwrite($fd, "$users_info");
						fclose ($fd);	
					}

					//Writing back to users file end

					//Add user to log if log is on
					if($session_array_sgcb[keep_log]){

						//First read log file if exists
						if(file_exists($log_file)){
							$fd = fopen ($log_file, "r");
							if($fd){$log_info = fread($fd, filesize($log_file));}
							fclose($fd);
						}

						if($fd = fopen ($log_file, "w")){

							@fwrite($fd, "$new_log_record\n$log_info");
							fclose ($fd);	
						}
					}
					//Add user to log if log is on end

				}//Check if user exists end
				

				//Send email to user
				
				//Expiration date
					$uexp_disp = "";
					if($uexp){

						unset($uexp_arr);
						$uexp_arr = explode("/",$uexp);
						$uexp_disp = date("d-M-Y",mktime(0,0,0,$uexp_arr[0],$uexp_arr[1],$uexp_arr[2]));

					}
				//Expiration date end
				$subject = "Login information";
$emailmessage .= "Dear $urealname,\n\nThank you for your purchase!\n";
$emailmessage .= "\n========================\n";
$emailmessage .= "You have purchased the following product:\n$cur_prod_descr\n\n";
$emailmessage .= "You have unlimited downloads until $uexp_disp.\n";
$emailmessage .= "To download please go to $sgcb_url and use username and password provided below:\n\n";
$emailmessage .= "Username:  $session_array_sgcb[newusername]\nPassword:  $session_array_sgcb[newpassword]\n\n";
$emailmessage .= "If your username and password don't work, try to open a new browser window\n";
$emailmessage .= "first, then enter above address manually and hit \"Enter\".\n";
$emailmessage .= "You may experiense this problem if you use web-based email servise like \"Hotmail\".\n\n";

if($session_array_sgcb[sysadmin] && $session_array_sgcb[sysadminemail]){
	$emailmessage .= "If you encounter any problems with download please email to $session_array_sgcb[sysadmin] at $session_array_sgcb[sysadminemail].\n\n";
}
$emailmessage .= "Thank you for your business!\n\n$session_array_sgcb[sysadmin]";
				@mail($uemail, $subject, $emailmessage,
					"From: $session_array_sgcb[sysadminemail]\nReply-To: $session_array_sgcb[sysadminemail]\nX-Mailer: PHP/".phpversion());

				//Send email to user end
			
			}//If user provided its real name and email - add it to its record end

			//################################

			$session_array_sgcb="";
			session_destroy();

			//Redirect user to product
			header("Location: $cur_prod_url");
			exit;
			
		} else{
			$res_msg = "<BR><FONT SIZE=\"2\" FACE=\"Arial\" COLOR=\"red\">Error: Product URL is missing!  ";

			if($session_array_sgcb[sysadmin] && $session_array_sgcb[sysadminemail]){
				$res_msg .= "Please contact <B>$session_array_sgcb[sysadmin]</B> at <a href=\"mailto:$session_array_sgcb[sysadminemail]\">$session_array_sgcb[sysadminemail]</a></FONT>";
			}
			$res_msg = urlencode($res_msg);

		$out_param="res_msg=$res_msg";
		}
	
	
	}//Retrieving product end
	//Find associated product end

}
//THANKYOUPAGE EXECUTION END


//###########################################################
//###########################################################


//SETTINGS EXECUTION
else if($run_settings &&  $authorized_user == "admin"){
	
	

	//Settings file format: Contact\nContactEmail\nSecret_Key\nKeep_log
	$settings_info = "$sysadmin\n$sysadminemail\n$secret_key\n$keep_log";
		
	
	$writetofile="yes";


	//Write to file only if needed
	if($writetofile){
		//Write new contents into config_file
		if($fd = fopen ($config_file, "w")){

			if(fwrite($fd, "$settings_info")){
				$wrtrslt = "ok";
			} else {
				$wrtrslt = "fail";
			}
			fclose ($fd);	
		} else {
			$wrtrslt = "fail";
		}
	} //Write to file only if needed end
	
	//assemble return message
	if($wrtrslt == "ok"){
		$res_msg="Settings have been saved  ";
	}
	else if($wrtrslt == "fail"){
		$res_msg="Failed to save settings!  ";
	}
	

	$res_msg = urlencode($res_msg);

	$out_param="res_msg=$res_msg";


	
}//SETTINGS EXECUTION END


//###########################################################
//###########################################################



//PRODUCTS EXECUTION
else if($run_products &&  $authorized_user == "admin"){
	
	
	
	unset($products_info);


	//First read products file if exists
	if(file_exists($products_file)){
		$fd = fopen ($products_file, "r");
		if($fd){$products_info = fread($fd, filesize($products_file));}
		fclose($fd);
	}
	
	unset($products_info_ar);
	$products_info_ar = explode("\n",$products_info);

	//##################
	//##################

	//Select Product
	if($products == "Select Product"){
	

	$writetofile="";
	
	//Check if product exixsts
	if($products_info_ar){

		foreach($products_info_ar as $key=>$val){
			unset($tmp_val_ar);
			$tmp_val_ar = explode("\t",$val);
			if($tmp_val_ar[0]){


				if($tmp_val_ar[0] == $upd_prod[0]){

					$writetofile="";
					$wrtrslt = "ok";
					$res_msg = "$tmp_val_ar[0]";
					$pid = $tmp_val_ar[0];
					$pexp = $tmp_val_ar[1];
					$pdescr = $tmp_val_ar[2];
					$purl = $tmp_val_ar[3];

				}
			}
		}
	}//Check if product exists end
	
	
	}//Select Product end

	
	//##################
	//##################


	//Update Product
	if($products == "Update Product"){
	
	$writetofile="yes";


		//Check if product exixsts
		if($products_info_ar){

			foreach($products_info_ar as $key=>$val){
				unset($tmp_val_ar);
				$tmp_val_ar = explode("\t",$val);
				if($tmp_val_ar[0]){


					if($tmp_val_ar[0] == $pid){

						//Assemble new file contents

						$writetofile="yes";
						$wrtrslt = "";

						$products_info_ar[$key] = "$pid\t$pexp\t$pdescr\t$purl"; 
						$res_msg = "$tmp_val_ar[0]";
					}
				}
			}
		}//Check if user exists end
			

		//Now reassemble products_file contents
		if($products_info_ar){
			$products_info="";

			foreach($products_info_ar as $key=>$val){
				$products_info .="$val\n";
			}
		}
		//Now reassemble products_file contents end

	
	}//Update Product end

	//##################
	//##################

	//Add Product
	if($products == "Add Product"){
	
	$writetofile="yes";
	
	//Check if product exixsts
	if($products_info_ar){
	
		foreach($products_info_ar as $key=>$val){
			unset($tmp_val_ar);
			$tmp_val_ar = explode("\t",$val);
			if($tmp_val_ar[0] == $pid){
				$writetofile="";
				$wrtrslt = "exist";
				$res_msg = "$pid";
			}
		}
	}//Check if product exixsts end
	

	//Assemble new file contents
	
		$products_info = "$pid\t$pexp\t$pdescr\t$purl\n$products_info";
		$res_msg = "$pid";
	
	}//Add Product end
	
	
	//##################
	//##################

	//Delete Product
	if($products == "Delete Product"){
		$writetofile="";
		
		//Remove selected products
		if($products_info_ar){
			
			//Go through every existing product
			foreach($products_info_ar as $key=>$val){
				unset($tmp_val_ar);
				$del_product="";
				$tmp_val_ar = explode("\t",$val);
				



				//If $del_all is set delete all products
				if($del_all){
					if($val){
						$writetofile="yes";
						$products_info_ar[$key]="";
						$res_msg .="$tmp_val_ar[0], ";
					}
				}
				//If $del_all is set delete all products end

				//Otherwise delete from list
				else {
					//Go through delete list
					foreach($delete_ar as $dkey=>$dval){
						if($tmp_val_ar[0] == $dval){
							if($dval){
								$writetofile="yes";
								$del_product="yes";
							}
						}
					}//Go through delete list end
	
					//Remove product and add record to message
					if($del_product){
						$products_info_ar[$key]="";
						$res_msg .="$tmp_val_ar[0], ";
					}
				}//Otherwise delete from list end

	
	
			}//Go through every existing product end
			
			//Cut off last comma
			$res_msg = substr($res_msg,0,strlen($res_msg)-2);

			if(!$writetofile){
				$res_msg ="No Products found to Delete";
			}

			//Now reassemble products_file contents
			$products_info="";
			foreach($products_info_ar as $key=>$val){
				if($val){$products_info .="$val\n";}
			}
			//Now reassemble products_file contents end
			

		}//Remove selected products end
		else {
			$res_msg ="No Products exists to Delete";
		}

		

	}//Delete Product end

	//##################
	//##################


	//Write to file only if needed
	if($writetofile){
		//Write new contents into products_file
		if($fd = fopen ($products_file, "w")){

			if(fwrite($fd, "$products_info")){
				$wrtrslt = "ok";
			} else {
				$wrtrslt = "fail";
			}
			fclose ($fd);	
		} else {
			$wrtrslt = "fail";
		}
	} //Write to file only if needed end
	
	//assemble return message
	if($wrtrslt == "ok"){
		if($flag == "add"){$res_msg="Product has been Added: <B>$res_msg</B>  ";$clear="yes";}
		if($flag == "del"){$res_msg="Products Deleted: <B>$res_msg</B>  ";}
		if($flag == "sel"){
			if($res_msg){$res_msg="Product Selected: <B>$res_msg</B>  ";}
			else {$res_msg="No Product has been Selected.  ";}
		}
		if($flag == "upd"){
			if($res_msg){$res_msg="Product Updated: <B>$res_msg</B>  ";$clear="yes";}
			else {$res_msg="No Product has been Updated.  ";}
		}
	}
	else if($wrtrslt == "fail"){
		if($flag == "add"){$res_msg="Failed to Add Product: <B>$res_msg</B>  ";}
		if($flag == "del"){
			if($products_info){
				$res_msg="Failed to Delete Products: <B>$res_msg</B>  ";
			} else {
				$res_msg="Products Deleted: <B>$res_msg</B>  ";
			}
		}
		if($flag == "upd"){$res_msg="Failed to Update Product: <B>$res_msg</B>  ";}
	}
	else if($wrtrslt == "exist"){
		if($flag == "add"){$res_msg="Product already exists: <B>$res_msg</B>  ";}
	}

	$res_msg = urlencode($res_msg);

	$out_param="action=$flag&res_msg=$res_msg&clear=$clear";


	
}//PRODUCTS EXECUTION END


//###########################################################
//###########################################################



//USER MANAGEMENT EXECUTION
if($run_user &&  $authorized_user == "admin"){
	
	
	
	unset($users_info);


	//First read password file if exists
	if(file_exists($users_file)){
		$fd = fopen ($users_file, "r");
		if($fd){$users_info = fread($fd, filesize($users_file));}
		fclose($fd);
	}
	
	unset($users_info_ar);
	$users_info_ar = explode("\n",$users_info);

	//##################
	//##################

	//Select user
	if($user == "Select User"){
	

	$writetofile="";
	
	//Check if user exixsts
	if($users_info_ar){

		foreach($users_info_ar as $key=>$val){
			unset($tmp_val_ar);
			$tmp_val_ar = explode(":",$val);
			if($tmp_val_ar[0]){


				if($tmp_val_ar[0] == $upd_usr[0]){

					$writetofile="";
					$wrtrslt = "ok";
					$res_msg = "$tmp_val_ar[0]";
					$uusername = $tmp_val_ar[0];
					$upass = $tmp_val_ar[1];
					

					if(crypt("admin$tmp_val_ar[0]",$tmp_val_ar[0]) == $tmp_val_ar[2]){
						$upriv = "admin";
					}

					$urealname = $tmp_val_ar[3];
					$uprod =  $tmp_val_ar[4];
					$uexp =  $tmp_val_ar[5];
					$uemail =  $tmp_val_ar[6];
				}
			}
		}
	}//Check if user exists end
	
	
	}//Select user end

	
	//##################
	//##################


	//Update user
	if($user == "Update User"){
	
	$writetofile="yes";


		//Check if user exixsts
		if($users_info_ar){

			foreach($users_info_ar as $key=>$val){
				unset($tmp_val_ar);
				$tmp_val_ar = explode(":",$val);
				if($tmp_val_ar[0]){


					if($tmp_val_ar[0] == $uusername){

						//Assemble new file contents
						if($upriv == "admin"){$user_priv = crypt("admin"."$uusername",$uusername);}
						else{$user_priv = crypt("user"."$uusername",$uusername);}
						
						//Make sure admin did not deprive himself of admin priveledge
						unset($tmp_cur_user_ar);
						$tmp_cur_user_ar=explode(":",$current_user);
						if($uusername == $tmp_cur_user_ar[0]){
							$user_priv = crypt("admin"."$uusername",$uusername);
						}
						//Make sure admin did not deprive himself of admin priveledge end

						$writetofile="yes";
						$wrtrslt = "";

						//Encrypt pass if it's been changed
						if($upass != $uoldpass){$upass=crypt($upass,$uusername);}

						$users_info_ar[$key] = "$uusername:$upass:$user_priv:$urealname:$uprod:$uexp:$uemail"; 
						$res_msg = "$tmp_val_ar[0]";
					}
				}
			}
		}//Check if user exists end
			

		//Now reassemble users_file contents
		if($users_info_ar){
			$users_info="";

			foreach($users_info_ar as $key=>$val){
				$users_info .="$val\n";
			}
		}
		//Now reassemble users_file contents end

	
	}//Update user end

	//##################
	//##################

	//Add user
	if($user == "Add User"){
	
	$writetofile="yes";
	
	//Check if user exixsts
	if($users_info_ar){
	
		foreach($users_info_ar as $key=>$val){
			unset($tmp_val_ar);
			$tmp_val_ar = explode(":",$val);
			if($tmp_val_ar[0] == $uusername){
				$writetofile="";
				$wrtrslt = "exist";
				$res_msg = "$uusername";
			}
		}
	}//Check if user exixsts end
	

	//Assemble new file contents
	if($upriv == "admin"){$user_priv = crypt("admin"."$uusername",$uusername);}
	else{$user_priv = crypt("user"."$uusername",$uusername);};

		$users_info = "$uusername:".crypt($upass,$uusername).":$user_priv:$urealname:$uprod:$uexp:$uemail\n$users_info";
		$res_msg = "$uusername";
	
	}//Add user end
	
	
	//##################
	//##################

	//Delete user
	if($user == "Delete User"){
		$writetofile="";
		
		//Remove selected users
		if($users_info_ar){
			
			//Go through every existing user
			foreach($users_info_ar as $key=>$val){
				unset($tmp_val_ar);
				$del_user="";
				$tmp_val_ar = explode(":",$val);
				
				unset($tmp_current_user);
				$tmp_current_user=explode(":",$current_user);

				//User can't detete itself
				if($tmp_val_ar[0] != $tmp_current_user[0]){

					//If $del_all is set delete all users
					if($del_all){
						if($val){
							$writetofile="yes";
							$users_info_ar[$key]="";
							$res_msg .="$tmp_val_ar[0], ";
						}
					}
					//If $del_all is set delete all users end
	
					//Otherwise delete from list
					else {
						//Go through delete list
						foreach($delete_ar as $dkey=>$dval){
							if($tmp_val_ar[0] == $dval){
								if($dval){
									$writetofile="yes";
									$del_user="yes";
								}
							}
						}//Go through delete list end
		
						//Remove user and add record to message
						if($del_user){
							$users_info_ar[$key]="";
							$res_msg .="$tmp_val_ar[0], ";
						}
					}//Otherwise delete from list end
				} //User can't detete itself end
	
	
			}//Go through every existing user end
			
			//Cut off last comma
			$res_msg = substr($res_msg,0,strlen($res_msg)-2);

			if(!$writetofile){
				$res_msg ="No User found to Delete or You selected yourself";
			}

			//Now reassemble users_file contents
			$users_info="";
			foreach($users_info_ar as $key=>$val){
				if($val){$users_info .="$val\n";}
			}
			//Now reassemble users_file contents end
			

		}//Remove selected users end
		else {
			$res_msg ="No User exists to Delete";
		}

		

	}//Delete user end

	//##################
	//##################


	//Write to file only if needed
	if($writetofile){
		//Write new contents into users_file
		if($fd = fopen ($users_file, "w")){

			if(fwrite($fd, "$users_info")){
				$wrtrslt = "ok";
			} else {
				$wrtrslt = "fail";
			}
			fclose ($fd);	
		} else {
			$wrtrslt = "fail";
		}
	} //Write to file only if needed end
	
	//assemble return message
	if($wrtrslt == "ok"){
		if($flag == "add"){$res_msg="User Added: <B>$res_msg</B>  ";$clear="yes";}
		if($flag == "del"){$res_msg="User Deleted: <B>$res_msg</B>  ";}
		if($flag == "sel"){
			if($res_msg){$res_msg="User Selected: <B>$res_msg</B>  ";}
			else {$res_msg="No User has been Selected.  ";}
		}
		if($flag == "upd"){
			if($res_msg){$res_msg="User Updated: <B>$res_msg</B>  ";$clear="yes";}
			else {$res_msg="No User has been Updated.  ";}
		}
	}
	else if($wrtrslt == "fail"){
		if($flag == "add"){$res_msg="Failed to Add User: <B>$res_msg</B>  ";}
		if($flag == "del"){
			if($users_info){
				$res_msg="Failed to Delete User: <B>$res_msg</B>  ";
			} else {
				$res_msg="User Deleted: <B>$res_msg</B>  ";
			}
		}
		if($flag == "upd"){$res_msg="Failed to Update User: <B>$res_msg</B>  ";}
	}
	else if($wrtrslt == "exist"){
		if($flag == "add"){$res_msg="User has already been Added: <B>$res_msg</B>  ";}
	}

	$res_msg = urlencode($res_msg);

	$out_param="action=$flag&res_msg=$res_msg&clear=$clear";


	
}//USER MANAGEMENT EXECUTION END


//###########################################################
//###########################################################


//DUMPING VARIABLES TO SESION ARRAY ############################################


$session_array_sgcb[nosysadmininfo]=$nosysadmininfo;

$session_array_sgcb[nouusername]=$nouusername;
$session_array_sgcb[noupass]=$noupass;
$session_array_sgcb[nouexp]=$nouexp;
$session_array_sgcb[nouprod]=$nouprod;

$session_array_sgcb[nopid]=$nopid;
$session_array_sgcb[nopurl]=$nopurl;
$session_array_sgcb[nopexp]=$nopexp;
$session_array_sgcb[nourealname]=$nourealname;
$session_array_sgcb[nouemail]=$nouemail;
$session_array_sgcb[nouemail1]=$nouemail1;

$session_array_sgcb[pid]=$pid;
$session_array_sgcb[pexp]=$pexp;
$session_array_sgcb[pdescr]=$pdescr;
$session_array_sgcb[purl]=$purl;
$session_array_sgcb[pkeyword]=$pkeyword;

$session_array_sgcb[uusername]=$uusername;
$session_array_sgcb[upass]=$upass;
$session_array_sgcb[urealname]=$urealname;
$session_array_sgcb[upriv]=$upriv;
$session_array_sgcb[uexp]=$uexp;
$session_array_sgcb[uprod]=$uprod;
$session_array_sgcb[uemail]=$uemail;
$session_array_sgcb[uemail1]=$uemail1;
$session_array_sgcb[ukeyword]=$ukeyword;


//strip html tags and slashes 
while ( list($key, $val) = each($session_array_sgcb) ) { 
	if(substr($key,0,2) != "no"){
		$session_array_sgcb[$key]=strip_tags($session_array_sgcb[$key]);
	}
$session_array_sgcb[$key]=str_replace("\"","'",$session_array_sgcb[$key]); 
$session_array_sgcb[$key]=stripslashes($session_array_sgcb[$key]); 
	if($session_array_sgcb[$key]==""){
		if($required_fields[$key]){
			$session_array_sgcb['no$key']="$required_fields[$key]";
			$errors="yes";
		}
	}
} 

$session_array_sgcb[company_logo] = $company_logo;

//######################### DUMPING VARIABLES TO SESION ARRAY END ##############

//Preparing globals to leave script
if($session_array_sgcb){
	$session_array_sgcb = serialize($session_array_sgcb);
	$session_array_sgcb = urlencode($session_array_sgcb);
}


session_register('session_array_sgcb');
//Preparing globals to leave script end


//Run appropriate form
header("Location: $install_dir/sgcb_form.php?run=$run&$out_param");


?>