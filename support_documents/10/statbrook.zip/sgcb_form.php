<?
//##################################################################################
//SALES GUARD CB FORM UTILITY
//SGCB.PHP 
//
//
//March 21, 2002
//Software Programs, Inc.  Copyright 2002 - 2003. - Houston, TX USA - All rights reserved.
//www.software-programs.net
//
//License:	Unlimited installations permitted.  Product modifications allowed.  
//			Redistribution prohibited without written approval. 
//
//##################################################################################
//
//REQUIREMENTS: Apache, PHP4



session_save_path("/home/users/web/b1632/ipw.betterlivingwithhypnosis/phpsessions");
session_start();


//SETTING VARIABLES ##################################################

$today = date("j-M-Y H:i:s");

$login_page="index.html";

$maintitle = "Sales Guard CB";

//prepare globals for handling
if($session_array_sgcb){
	$session_array_sgcb = urldecode($session_array_sgcb);
	$session_array_sgcb = unserialize($session_array_sgcb);
} else {

	header("Location: $login_page");
	exit;
}
//prepare globals for handling end




$authorized_user = $session_array_sgcb[authorized_user];
$current_user = $session_array_sgcb[current_user];


$newusername = $session_array_sgcb[newusername];
$newpassword = $session_array_sgcb[newpassword];
$newitem = $session_array_sgcb[newitem];


$install_dir = $session_array_sgcb[install_dir];
$sgcb_url = $session_array_sgcb[sgcb_url];
$home_url = $session_array_sgcb[home_url];
$backup_dir = $session_array_sgcb[backup_dir];
$config_file = $session_array_sgcb[config_file];
$users_file = $session_array_sgcb[users_file];
$products_file = $session_array_sgcb[products_file];
$log_file = $session_array_sgcb[log_file];
$sysadmin = $session_array_sgcb[sysadmin];
$sysadminemail = $session_array_sgcb[sysadminemail];

$enforce_customer_emails = $session_array_sgcb[enforce_customer_emails];
$keep_log = $session_array_sgcb[keep_log];
$secret_key = $session_array_sgcb[secret_key];

$sec_dir_info = $session_array_sgcb[sec_dir_info];
$customer_email_submitted = $session_array_sgcb[customer_email_submitted];

$nosysadmininfo=$session_array_sgcb[nosysadmininfo];
$nouusername=$session_array_sgcb[nouusername];
$noupass=$session_array_sgcb[noupass];
$nouexp=$session_array_sgcb[nouexp];
$nourealname=$session_array_sgcb[nourealname];
$nouemail=$session_array_sgcb[nouemail];
$nouemail1=$session_array_sgcb[nouemail1];

$nopid=$session_array_sgcb[nopid];
$nopexp=$session_array_sgcb[nopexp];
$nopurl=$session_array_sgcb[nopurl];


$dir_affected=$session_array_sgcb[dir_affected];
$usr_selected=$session_array_sgcb[usr_selected];
$write_failed=$session_array_sgcb[write_failed];



$pid=$session_array_sgcb[pid];
$pexp=$session_array_sgcb[pexp];
$pdescr=$session_array_sgcb[pdescr];
$purl=$session_array_sgcb[purl];
$pkeyword=$session_array_sgcb[pkeyword];

$uusername=$session_array_sgcb[uusername];
$upass=$session_array_sgcb[upass];
$urealname=$session_array_sgcb[urealname];
$upriv=$session_array_sgcb[upriv];
$uprod=$session_array_sgcb[uprod];
$uexp=$session_array_sgcb[uexp];
$uemail=$session_array_sgcb[uemail];
$uemail1=$session_array_sgcb[uemail1];

//Part of a Search function 8
$ukeyword=$session_array_sgcb[ukeyword];
//Part of a Search function 8 end


$company_logo = $session_array_sgcb[company_logo];
$text_color=$session_array_sgcb[text_color];
$current_user_color=$session_array_sgcb[current_user_color];
$title_color = $session_array_sgcb[title_color];
$bg_color = $session_array_sgcb[bg_color];
$alt_bg_color = $session_array_sgcb[alt_bg_color];
$alt_text_color = $session_array_sgcb[alt_text_color];
$msgcb_bg_color = $session_array_sgcb[msgcb_bg_color];
$title_bg_color = $session_array_sgcb[title_bg_color];
$special_text_color = $session_array_sgcb[special_text_color];
//######################## SETTING VARIABLES END #####################


//Clear some variables if $clear is set
if($clear){
	$uusername = ""; 
	$upass=""; 
	$urealname = "";
	$uexp = "";
	$uprod = "";
	$upriv = "";
	$uemail = "";
	$uemail1 = "";
	$ukeyword = "";

	$nouusername = ""; 
	$noupass=""; 
	$nourealname = "";
	$nouexp = "";
	$nouemail = "";
	$nouemail1 = "";

	$session_array_sgcb[uusername] = ""; 
	$session_array_sgcb[upass]=""; 
	$session_array_sgcb[urealname] = ""; 
	$session_array_sgcb[upriv] = "";
	$session_array_sgcb[uexp] = "";
	$session_array_sgcb[uprod] = "";

	//Part of a Search function 9
	$session_array_sgcb[ukeyword] = ""; 
	//Part of a Search function 9 end

	$session_array_sgcb[nouusername] = ""; 
	$session_array_sgcb[noupass]=""; 
	$session_array_sgcb[nourealname] = "";
	$session_array_sgcb[nouexp] = "";
	$session_array_sgcb[nouemail] = "";
	$session_array_sgcb[nouemail1] = "";

	$pid = ""; 
	$pexp=""; 
	$pdescr = ""; 
	$purl = "";
	$pkeyword = "";
	
	$nopid = ""; 
	$nopurl=""; 

	$session_array_sgcb[pid] = ""; 
	$session_array_sgcb[pexp]=""; 
	$session_array_sgcb[pdescr] = ""; 
	$session_array_sgcb[purl] = "";
	$session_array_sgcb[pkeyword] = "";

	$session_array_sgcb[nopid] = ""; 
	$session_array_sgcb[nopurl]=""; 
	
}//Clear some variables if $clear is set end

//Preparing globals to leave script
if($session_array_sgcb){
	$session_array_sgcb = serialize($session_array_sgcb);
	$session_array_sgcb = urlencode($session_array_sgcb);
}
//session_register('session_array_sgcb');
if (session_status() == PHP_SESSION_NONE) {
    session_start();
}
$_SESSION['session_array_sgcb'] =  $session_array_sgcb;

//Preparing globals to leave script end



// CONSTRUCTING FORMS ###############################################



//SECURITY CHECK ###################################################################

if($authorized_user){

//FUNCTION TO READ PRODUCTS

function read_products($products_file,$uprod,$text_color,$alt_text_color,$alt_bg_color,$bg_color,$pkeyword){
	
	
//First read products file if exists
	if(file_exists($products_file)){
		$fd = fopen ($products_file, "r");
		if($fd){$products_info = fread($fd, filesize($products_file));}
		fclose($fd);
	}
	
	//Retrieving products
	if(!$products_info){return;}
	else{

		if(@eregi($pkeyword,$products_info) && $pkeyword){$psearchword = $pkeyword;}

		$products_arr=explode("\n",$products_info);

		asort($products_arr);
		
		$found_records = 0;
		
		foreach($products_arr as $key=>$val){
			

			//If search word was specified select only products with matching patterns
			$include="yes";
			if($psearchword){
				if(!eregi($psearchword,$val)){$include = "";}
				else{$found_records++;}
			}
			
			if($include){

				//Product storage format: pid <tab> expiration  <tab> description <tab> URL
				unset($cur_prod_ar);
				$cur_prod_ar=explode("\t",$val);

				//if entry is not empty
				if($cur_prod_ar[0]){
					
					//trim description to 20 symbols
					$curent_prod_descr = "";
					$descr_ending = "";
					if(strlen($cur_prod_ar[2]) > 40){$descr_ending="...";}
					$curent_prod_descr=substr($cur_prod_ar[2],0,40).$descr_ending;
					
					//Produce different product lists if function called differently
					$selected="";
					if($uprod >= 0 && $uprod != ""){
						
						if($uprod == $cur_prod_ar[0]){$selected="selected";}
						
						$prod_exp_date = date("d-M-Y",mktime(0,0,0,date("m"),date("d")+$cur_prod_ar[1],date("Y")));

						$product_list .= "<option value=\"$cur_prod_ar[0]\" $selected>$cur_prod_ar[0] --- $prod_exp_date --- $curent_prod_descr</option>";

					} else {
					
						$product_list .= "<option value=\"$cur_prod_ar[0]\" >$cur_prod_ar[0] --- $cur_prod_ar[1] days --- $curent_prod_descr</option>";
					}
					//Produce different product lists if function called differently end


					if($curr_bg_color != $alt_bg_color){$curr_bg_color = $alt_bg_color;}
					else {$curr_bg_color = $bg_color;}
					
					//trim URL to 45 symbols
					$curent_prod_url = "";
					$url_ending = "";
					if(strlen($cur_prod_ar[3]) > 45){$url_ending="...";}
					$curent_prod_url=substr($cur_prod_ar[3],0,45).$url_ending;

					$product_list_add .= "
					<tr bgcolor=\"$curr_bg_color\">
					<td align=\"center\"><FONT FACE=\"Arial\" COLOR=\"$alt_text_color\" size=\"2\">$cur_prod_ar[0]</FONT>
					</td>
					<td align=\"center\"><FONT FACE=\"Arial\" COLOR=\"$alt_text_color\" size=\"2\">$cur_prod_ar[1]</FONT>
					</td>
					<td><FONT FACE=\"Arial\" COLOR=\"$alt_text_color\" size=\"2\">$cur_prod_ar[2]</FONT>
					</td>
					<td align=\"center\"><a href=\"$cur_prod_ar[3]\" target=_blank><FONT FACE=\"Arial\" size=\"2\">$curent_prod_url</font></a>
					</td>
					</tr>";

				}//if entry is not empty end
				
			}//If search word was specified select only users with matching patterns end
		}//foreach end


		
		$product_list_add = "
			<TABLE WIDTH=\"100%\">
			<TR>
				<TD align=\"center\"><FONT FACE=\"Arial\" COLOR=\"$text_color\" size=\"2\">
				<B>Product ID</B>
				</FONT></TD>
				<TD align=\"center\"><FONT FACE=\"Arial\" COLOR=\"$text_color\" size=\"2\">
				<B>Expiration</B>
				</FONT></TD>
				<TD align=\"center\"><FONT FACE=\"Arial\" COLOR=\"$text_color\" size=\"2\">
				<B>Description</B>
				</FONT></TD>
				<TD align=\"center\" ><FONT FACE=\"Arial\" COLOR=\"$text_color\" size=\"2\">
				<B>Download URL</B> 
				</FONT></TD>
			</TR>
			$product_list_add
			</TABLE>
		";
		if($pkeyword && $res_msg == ""){
			if($found_records > 0){
				$res_msg .= "Total <B>$found_records</B> products containing <B>\"$pkeyword\"</B> found";
			} else{
				$res_msg .= "No products containing <B>\"$pkeyword\"</B> found";
			}
		
		}
		

	}//Retrieving Products end
	
	unset($existing_products);
	$existing_products = array("0"=>$product_list,"1"=>$product_list_add,"2"=>$res_msg);
	

	if($product_list){return $existing_products;}
}
//FUNCTION TO READ PRODUCTS END


//##############################################################################
//##############################################################################


//DISPLAY THANK YOU PAGE FOR REGULAR USERS
if($run == "thankyoupage" && $authorized_user == "user"){
	
	$res_msg = urldecode($res_msg);
	
	//Extract user's real name and product id from current_user
	unset($tmp_cur_user);
	$tmp_cur_user=explode(":",$current_user);	

	
	$cur_username = $tmp_cur_user[0];
	$cur_name = $tmp_cur_user[1];
	$cur_product = $tmp_cur_user[2];
	
	if(!$cur_name){$cur_name = $cur_username;}
	else {$cur_name = "$cur_name ($cur_username)";}

	unset($cur_exp_arr);
	$cur_exp_arr = explode("/",$tmp_cur_user[3]);
	$then = mktime(0,0,0,date($cur_exp_arr[0]),date($cur_exp_arr[1]),date($cur_exp_arr[2]));
	$now = mktime(0,0,0,date("m"),date("d"),date("Y"));
	$days_left = ($then-$now)/86400;
	$days_left=number_format("$days_left","","",",");
	$cur_exp = date("d-M-Y", $then);

	//Find associated product
	if(file_exists($products_file)){
		$fd = fopen ($products_file, "r");
		if($fd){$products_info = fread($fd, filesize($products_file));}
		fclose($fd);
	}
	
	//Retrieving product
	if(!$products_info){
		$merchant_message = "<BR><BR>This product has been discontinued.  ";
		if($sysadmin && $sysadminemail){
			$merchant_message .= "If you think this is an error or you have more questions please contact <B>$sysadmin</B> at <a href=\"mailto:$sysadminemail\"><FONT SIZE=\"2\" FACE=\"Arial\">$sysadminemail</FONT></a>.";
		}
		$title = "Product Discontinued";
		$action_title = "$cur_name<BR>Product Discontinued";
	}
	else{

		$products_arr=explode("\n",$products_info);


		//if products exist
		if($products_arr){
			foreach($products_arr as $key=>$val){
				unset($val_ar);
				$val_ar = explode("\t",$val);
				if($val_ar[0] == $cur_product && $cur_product){
					$cur_prod_descr = $val_ar[2]; //product description
					$pid_found = "yes";
				}
			}//foreach end
		}//if products exist end

		//Add download button if product found
		if($pid_found){
			
			
			//If submittion of buyer's email is not enforced
				if($enforce_customer_emails != "checked"){
						
				//Providing username and password for new users
				if($newusername && $newpassword){
					$merchant_message .= "<BR><BR><CENTER><B>PLEASE PRINT THIS PAGE NOW! </B></CENTER><BR><BR>You can NOT bookmark this page.  As soon as you hit \"Download Now\" button your product will start downloading and you will be automatically logged off (this page will disappear after 2-nd click on the \"Download Now\" button).<br><BR>You have unlimited number of downloads for this product until <B>$cur_exp</B>.  You have <B>$days_left</B> days left.<BR>If you'd like to download this product later, you can do it by going to <b>$sgcb_url</b>.  Please use the following username and password to login:<br><br><CENTER>Username: <b>$newusername</b><br>Password: <b>$newpassword</b>
<br>




</CENTER>
<br>
<br>

<img 
src=\"https://www.clixGalore.com/AdvTransaction.aspx?AdID=8666&SV=29.95&OID=$cur_name\" height=\"0\" width=\"0\" border=\"0\">
					<FONT COLOR=\"#990033\"><CENTER>Your credit card statement will show a charge from ClickBank/Keynetics.</CENTER></FONT><br>
					<hr><br>If you want to have these username and password emailed to you, please fill out the form below.  Email will be sent to you as soon as you hit \"Download Now\" button.  
					<CENTER><TABLE>
					<TR>
						<TD><FONT FACE=\"Arial\" SIZE=\"2\" COLOR=\"$text_color\">Your name:</FONT></TD>
						<TD>
							<span style=\"background-color: #FFFF00\"><FONT FACE=\"Arial\" size=\"2\">$nourealname</FONT></span>
							<input type=\"text\" name=\"urealname\" value=\"$urealname\"></TD>
					</TR>
					<TR>
						<TD><FONT FACE=\"Arial\" SIZE=\"2\" COLOR=\"$text_color\">Your email:</FONT></TD>
						<TD>
							<span style=\"background-color: #FFFF00\"><FONT FACE=\"Arial\" size=\"2\">$nouemail</FONT></span>	
							<input type=\"text\" name=\"uemail\" value=\"$uemail\"></TD>
					</TR>
					<TR>
						<TD><FONT FACE=\"Arial\" SIZE=\"2\" COLOR=\"$text_color\">Re-enter your email:</FONT></TD>
						<TD>
							<span style=\"background-color: #FFFF00\"><FONT FACE=\"Arial\" size=\"2\">$nouemail1</FONT></span>	
							<input type=\"text\" name=\"uemail1\" value=\"$uemail1\"></TD>
					</TR>
					</TABLE></CENTER>
					<hr><br>";

					$title = "$cur_name  Thank you for your purchase!";
					$action_title = "$cur_name<BR>Thank you for your purchase!";
				} else{

					$merchant_message .= "<BR><BR><CENTER>Your download period expires on <B>$cur_exp</B>.  You have <B>$days_left</B> days left.</CENTER><br><BR>";
					$title = "$cur_name  Welcome back!";
					$action_title = "$cur_name<BR>Welcome back!";
				}
				


				if($sysadmin && $sysadminemail){
					$merchant_message .= "<CENTER>If you encounter any problems with download please contact <b>$sysadmin</b> at <a href=\"mailto:$sysadminemail\"><FONT SIZE=\"2\" FACE=\"Arial\">$sysadminemail</FONT></a>.<BR>We hope you enjoy this experience!<BR></CENTER>";
				}
		
				$merchant_message .= "<br><FONT SIZE=\"2\" COLOR=\"$alt_text_color\"><CENTER><B>$cur_prod_descr</B></CENTER></FONT><BR><BR>";
				
				
				
				$download_button = "
					<input type=\"hidden\" name=\"inscript\" value=\"yes\">			
					<input type=\"submit\" name=\"thankyoupage\" value=\"Download Now\">
				";

			}//If submittion of buyer's email IS NOT enforced end
			
			//If submittion of buyer's email IS enforced
			else{
				
				//Customer email submitted
				if($customer_email_submitted == "yes"){
					
					//Providing username and password for new users
					if($newusername && $newpassword){
						$merchant_message .= "<BR><BR><CENTER><B>PLEASE PRINT THIS PAGE NOW!</B></CENTER><BR><BR>You can NOT bookmark this page.  As soon as you hit \"Download Now\" button your product will start downloading and you will be automatically logged off (this page will disappear after 2-nd click on the \"Download Now\" button).<br><BR>You have unlimited number of downloads for this product until <B>$cur_exp</B>.  You have <B>$days_left</B> days left.<BR>If you'd like to download this product later, you can do it by going to <b>$sgcb_url</b>.  Please use the following username and password to login:<br><br><CENTER>Username: <b>$newusername</b><br>Password: <b>$newpassword</b></CENTER><br><hr>
						";

						$title = "$cur_name  Thank you for your purchase!";
						$action_title = "$cur_name<BR>Thank you for your purchase!";
					} 
					


					if($sysadmin && $sysadminemail){
						$merchant_message .= "If you encounter any problems with download please contact <b>$sysadmin</b> at <a href=\"mailto:$sysadminemail\"><FONT SIZE=\"2\" FACE=\"Arial\">$sysadminemail</FONT></a>.<BR>We hope you enjoy this experience!<BR>";
					}
			
					$merchant_message .= "<br><FONT SIZE=\"2\" COLOR=\"$alt_text_color\"><CENTER><B>$cur_prod_descr</B></CENTER></FONT><BR><BR>";
					
					
					
					$download_button = "
						<input type=\"hidden\" name=\"inscript\" value=\"yes\">			
						<input type=\"submit\" name=\"thankyoupage\" value=\"Download Now\">
					";

				}//Customer email submitted end

				//Customer email is not yet submitted
				else if($newusername && $newpassword){

					//Providing username and password for new users
					
						$merchant_message .= "<BR><BR><CENTER><B>Please enter your full name and e-mail.  Your username and password will be e-mailed to you.  Product download button will be displayed as soon as you complete e-mail information.  
						<CENTER><TABLE>
						<TR>
							<TD><FONT FACE=\"Arial\" SIZE=\"2\" COLOR=\"$text_color\">Your name:</FONT></TD>
							<TD>

								<span style=\"background-color: #FFFF00\"><FONT FACE=\"Arial\" size=\"2\">$nourealname</FONT></span>
								<input type=\"text\" name=\"urealname\" value=\"$urealname\"></TD>
						</TR>
						<TR>
							<TD><FONT FACE=\"Arial\" SIZE=\"2\" COLOR=\"$text_color\">Your email:</FONT></TD>
							<TD>
								<span style=\"background-color: #FFFF00\"><FONT FACE=\"Arial\" size=\"2\">$nouemail</FONT></span>	
								<input type=\"text\" name=\"uemail\" value=\"$uemail\"></TD>
						</TR>
						<TR>
							<TD><FONT FACE=\"Arial\" SIZE=\"2\" COLOR=\"$text_color\">Re-enter your email:</FONT></TD>
							<TD>
								<span style=\"background-color: #FFFF00\"><FONT FACE=\"Arial\" size=\"2\">$nouemail1</FONT></span>	
								<input type=\"text\" name=\"uemail1\" value=\"$uemail1\"></TD>
						</TR>
						</TABLE></CENTER>
						<hr><br>";

						$title = "$cur_name  Please enter your e-mail information.";
						$action_title = "$cur_name<BR>Please enter your e-mail information";
					
					
					
					
					$download_button = "
						<input type=\"hidden\" name=\"inscript\" value=\"yes\">	
						<input type=\"hidden\" name=\"email_form\" value=\"yes\">	
						<input type=\"submit\" name=\"thankyoupage\" value=\"Submit\">
					";
				
				}//Customer email is not yet submitted end
				
				//It's a returning customer - display download link
				else{

						$merchant_message .= "<BR><BR><CENTER>Your download period expires on <B>$cur_exp</B>.  You have <B>$days_left</B> days left.</CENTER><br><BR>";
						$title = "$cur_name  Welcome back!";
						$action_title = "$cur_name<BR>Welcome back!";

						if($sysadmin && $sysadminemail){
							$merchant_message .= "If you encounter any problems with download please contact <b>$sysadmin</b> at <a href=\"mailto:$sysadminemail\"><FONT SIZE=\"2\" FACE=\"Arial\">$sysadminemail</FONT></a>.<BR>We hope you enjoy this experience!<BR>";
						}
			
					$merchant_message .= "<br><FONT SIZE=\"2\" COLOR=\"$alt_text_color\"><CENTER><B>$cur_prod_descr</B></CENTER></FONT><BR><BR>";
					
					
					
					$download_button = "
						<input type=\"hidden\" name=\"inscript\" value=\"yes\">			
						<input type=\"submit\" name=\"thankyoupage\" value=\"Download Now\">";

				}//It's a returning customer - display download link end

				

			}//If submittion of buyer's email IS enforced end

			
		} else{
			$merchant_message = "<BR><BR>This product has been discontinued.  ";
			if($sysadmin && $sysadminemail){
				$merchant_message .= "If you have more questions please contact <B>$sysadmin</B> at <a href=\"mailto:$sysadminemail\"><FONT SIZE=\"2\" FACE=\"Arial\">$sysadminemail</FONT></a>.<BR><BR><BR>";
			}
			$title = "Product Discontinued";
			$action_title = "$cur_name<BR>Product Discontinued";
		}
		//Add download button if product found end
	
	
	
	}//Retrieving product end
	//Find associated product end


	$user_display_form = "
		<TR>
		<TD valign=\"top\" bgcolor=\"$bg_color\" colspan=\"2\">
			<form method=\"POST\" action=\"sgcb.php\">
				
					
					<CENTER>
					<table width=\"100%\">
					<tr>
					<td width=\"5%\">&nbsp;</td>
					<td width=\"90%\">
					<FONT FACE=\"Arial\" SIZE=\"2\" COLOR=\"$text_color\">
					$merchant_message	
					<CENTER>$download_button</CENTER>
					</FONT>
					</td>
					<td width=\"5%\">&nbsp;</td>
					</tr>
					</table>
				</CENTER>
				
			</form>
			$res_msg
		</TD>
		</TR>
	";

	

}
//DISPLAY THANK YOU PAGE FOR REGULAR USERS END


//##############################################################################
//##############################################################################


//DISPLAY SETTINGS FORM

else if($run == "settings" && $authorized_user == "admin"){

	
	
	unset($settings_info);


	//First read config file if exists
	if(file_exists($config_file)){
		$fd = fopen ($config_file, "r");
		if($fd){$settings_info = fread($fd, filesize($config_file));}
		fclose($fd);
	}
	
	unset($settings_info_ar);
	$settings_info_ar = explode("\n",$settings_info);
	
	if($settings_info_ar){
		//Read from config only if not returned with error after checking
		if(!$nosysadmininfo){
			$sysadmin =  $settings_info_ar[0];	//Contact
			$sysadminemail =  $settings_info_ar[1];	//Contact's email
		}
		$secret_key = $settings_info_ar[2]; //Secret Key	
		$keep_log = $settings_info_ar[3];	//Keep Log
		$enforce_customer_emails = $settings_info_ar[4];	//Enforce customers's email collection
	}
	
	$title = "Change Settings";
	$help_id = "settings";
	


	//Checking if log exists
	
	if(file_exists($log_file)){$log_exists = "yes";}

	if($log_exists){
		$display_log = "
			<tr>
				<td colspan=\"2\">
				<hr>
				<a href=\"javascript: sgcb_log=window.open('$install_dir/sgcb_log.php','sgcb_log','width=550,height=500,toolbar=yes,scrollbars=yes, resizable=yes, top=30,left=300');sgcb_log.focus();void('');\"><font color=\"$text_color\" face=\"Arial\" size=\"2\">View log</font></a><BR>

				<a href=\"javascript: sgcb_log=window.open('$install_dir/sgcb_log.php?log_id=master','sgcb_log','width=550,height=500,toolbar=yes,scrollbars=yes, resizable=yes, top=30,left=300');sgcb_log.focus();void('');\"><font color=\"$text_color\" face=\"Arial\" size=\"2\">Create master mail list</font></a><BR>

				
				<a href=\"javascript: sgcb_log=window.open('$install_dir/sgcb_log.php?log_id=product','sgcb_log','width=550,height=500,toolbar=yes,scrollbars=yes, resizable=yes, top=30,left=300');sgcb_log.focus();void('');\"><font color=\"$text_color\" face=\"Arial\" size=\"2\">Create mail lists by product</font></a>
				</td>
			</tr>	
		";
	}
	//Checking if log exists end
	

	$res_msg = urldecode($res_msg);
	

		$settings_form = "
				
			<form method=\"POST\" action=\"sgcb.php\">
			
			  <table border=\"0\" width=\"100%\">
			  	 
			
			<tr>
				<td >
				
				<font face=\"Arial\" color=\"$text_color\" size=\"2\">Name of a contact: </font>
				</td>
				<td><span style=\"background-color: #FFFF00\"><FONT FACE=\"Arial\" size=\"2\">$nosysadmininfo</FONT></span>
				<input type=\"text\" name=\"sysadmin\" value=\"$sysadmin\" size=\"30\" maxlength=\"30\">
				<font face=\"Arial\" color=\"$text_color\" size=\"2\"> (For example: \"<I>Customer Support</I>\")</font></td>
			</tr>
			<tr>
				<td >
				<font face=\"Arial\" color=\"$text_color\" size=\"2\">Contact email: </font>
				</td>
				<td>
				<input type=\"text\" name=\"sysadminemail\" value=\"$sysadminemail\" size=\"30\" maxlength=\"100\"><font face=\"Arial\" color=\"$text_color\" size=\"2\"> (For example: \"<I>support@yourdomain.com</I>\")</font>
				</td>
			</tr>
			<tr>
				<td >
				<font face=\"Arial\" color=\"$text_color\" size=\"2\">Secret key: </font>
				</td>
				<td>
				<input type=\"text\" name=\"secret_key\" value=\"$secret_key\" size=\"16\" maxlength=\"16\">
				<font face=\"Arial\" color=\"$text_color\" size=\"2\"> (Same as in Clickbank)</font>
				</td>
			</tr>
			<tr>
				<td >
					<font face=\"Arial\" color=\"$text_color\" size=\"2\">Keep e-mail log: </font>
				</td>
				<td>
					<input type=\"checkbox\" name=\"keep_log\" $keep_log>
				</td>
			</tr>
			<tr>
				<td >
					<font face=\"Arial\" color=\"$text_color\" size=\"2\">Force e-mail collection: </font>
				</td>
				<td>
					<input type=\"checkbox\" name=\"enforce_customer_emails\" $enforce_customer_emails>
					<font face=\"Arial\" color=\"$text_color\" size=\"2\"> (<FONT COLOR=\"red\">WARNING</FONT>: Can be considered unethical by Clickbank)</font>
				</td>
			</tr>
			<tr>
				<td colspan=\"2\">
					<input type=\"hidden\" name=\"inscript\" value=\"yes\">					
					<input type=\"submit\" name=\"settings\" value=\"Submit\">
				</td>
			</tr>
			$display_log

			
			</table>
			</form>
			";


	//Finalizing settings

	$action_title = "Change Settings";

	if($res_msg){
		$results_disp = "
		<tr bgcolor=\"$msgcb_bg_color\">
		<td width=\"100%\">
			<FONT FACE=\"Arial\" COLOR=\"$text_color\" size=\"2\">$res_msg</FONT>&nbsp;
		  </td>
		</tr>";
	} else {
		$results_disp = "<tr><td>&nbsp;</td></tr>";
	}

	$display_form ="
	
	
<table border=\"0\" width=\"100%\">

	
	</tr>
	
		$results_disp

	<tr>
    <td align=\"left\">

    $settings_form

  </td>
  </tr>
</table>

  ";



	
}//DISPLAY SETTINGS FORM END



//##############################################################################
//##############################################################################


//DISPLAY PRODUCTS MANAGEMENT FORM

else if($run == "products" && $authorized_user == "admin"){

	$title = "Manage Products";
	$help_id = "products";
	
	

	$res_msg = urldecode($res_msg);
	$action_links="
		<A HREF=\"sgcb_form.php?run=products&action=add&clear=yes\"><font color=\"$text_color\" face=\"Arial\" size=\"2\">Add Products</font></A>
		&nbsp;&nbsp;
		<A HREF=\"sgcb_form.php?run=products&action=del&clear=yes\"><font color=\"$text_color\" face=\"Arial\" size=\"2\">Delete Products</font></A>
		&nbsp;&nbsp;
		<A HREF=\"sgcb_form.php?run=products&action=upd&clear=yes\"><font color=\"$text_color\" face=\"Arial\" size=\"2\">Update Products</font></A>";

	

		unset($prod_lists);
		$prod_lists=read_products($products_file,-1,$text_color,$alt_text_color,$alt_bg_color,$bg_color,$pkeyword);
		

		if($prod_lists){
			$product_list = $prod_lists[0];
			$product_list_add = $prod_lists[1];
			if($pkeyword && $res_msg == ""){$res_msg = $prod_lists[2];}
		} else{
			$res_msg .="<FONT COLOR=\"$text_color\" size=\"2\">Currently no products exist</FONT>";
		}

		//Delete Product selected  
		if($action == "del"){
	

		if($product_list){
			$product_list = "<font face=\"Arial\" color=\"$text_color\" size=\"2\">Select products from the list:<br><B>Product ID -- Expiration -- Description</B><br></font>

				<select size=\"10\" name=\"pdelete_list[]\" multiple>
    			$product_list
				<option value=\"*DELETE ALL PRODUCTS*\">*DELETE ALL PRODUCTS*</option>
				</select>";

			$delete_form = "
				
			<form method=\"POST\" action=\"sgcb.php\">
			<font face=\"Arial\" color=\"$text_color\" size=\"2\">&nbsp;Find product: </font>
			<input type=\"text\" name=\"pkeyword\" value=\"$pkeyword\" size=\"30\">
			<input type=\"submit\" name=\"submit\" value=\"Go\">
			<HR>
			  <table border=\"0\">
			  
			 
			
			<tr>
				<td colspan=\"2\">
				$product_list
				</td>
			</tr>
			<tr>
				<td colspan=\"2\" valign=\"top\">
					<font face=\"Arial\" color=\"$text_color\" size=\"2\">or type comma-separated product id's:</font><br>
					<input type=\"hidden\" name=\"products\" value=\"Delete Product\">
				  <input type=\"text\" name=\"palt_delete\" size=\"45\">
					
					<input type=\"hidden\" name=\"inscript\" value=\"yes\">
					
					&nbsp;&nbsp;<input type=\"submit\" name=\"submit\" value=\"Delete Product\">
					
				</td>
				<td>&nbsp;
				</td>
			</tr>


			
			</table>
			</form>
			";
		}

	//Finalizing delete list

	$action_title = "Delete Product";

	if($res_msg){
		$results_disp = "
		<tr bgcolor=\"$msgcb_bg_color\">
		<td width=\"100%\">
			<FONT FACE=\"Arial\" COLOR=\"$text_color\" size=\"2\">$res_msg</FONT>&nbsp;
		  </td>
		</tr>";
	} else {
		$results_disp = "<tr><td>&nbsp;</td></tr>";
	}

	$display_form ="
	
	
<table border=\"0\" width=\"100%\">

	<tr>
		<td align=\"left\">
		$action_links
	</td>
	</tr>
	
		$results_disp

	<tr>
    <td align=\"left\">

    $delete_form

  </td>
  </tr>
</table>

  ";

	
	
	}//Delete Product selected  end


//################
//################



//Select Update  product 
	else if($action=="upd" || $action=="sel") {



	if($product_list){
		$product_list="
			
		<form method=\"POST\" action=\"sgcb.php\">
			<font face=\"Arial\" color=\"$text_color\" size=\"2\">&nbsp;Find product: </font>
			<input type=\"text\" name=\"pkeyword\" value=\"$pkeyword\" size=\"30\">
			<input type=\"submit\" name=\"submit\" value=\"Go\">
			<HR>
		<table border=\"0\">
		<tr>
			<td colspan=\"2\">
			
				
			

			<TABLE>
			<TR>
				<TD valign=\"top\">
					
					<font face=\"Arial\" color=\"$text_color\" size=\"2\">Select Product To Update<BR><B>Product ID -- Expiration -- Description</B><br></font>
					<select size=\"10\" name=\"upd_prod[]\">
					$product_list
					</select>
				</TD>
			</TR>
			<TR>
				<TD valign=\"top\">
					<input type=\"hidden\" name=\"inscript\" value=\"yes\">
					
					<input type=\"hidden\" name=\"products\" value=\"Select Product\">
					<input type=\"submit\" name=\"submit\" value=\"Select Product\">
				</TD>
			</TR>
			</TABLE>
			
			</form>
				
			</td>
		</tr>

		<tr>
		<td width=\"100\"> <form method=\"POST\" action=\"sgcb.php\">		
			<font face=\"Arial\" color=\"$text_color\" size=\"2\">Product ID:</font>
		</td>
		<td>   
            <font face=\"Arial\" color=\"$text_color\" size=\"2\"><B>$pid</B></font>
			
		</td>
		
	</tr>
	<tr>
		<td>
			<font face=\"Arial\" color=\"$text_color\" size=\"2\">Expires in:</font>
		</td>
		<td valign=\"top\">
			<span style=\"background-color: #FFFF00\"><FONT FACE=\"Arial\" size=\"2\">$nopexp</FONT></span>
 			<input type=\"text\" name=\"pexp\" size=\"5\" maxlength=\"5\" value=\"$pexp\">
			&nbsp;&nbsp;<font face=\"Arial\" color=\"$text_color\" size=\"2\">days.</font>
        </td>
		
	</tr>
	<tr>
		<td>
			<font face=\"Arial\" color=\"$text_color\" size=\"2\">Description:</font>
		</td>
		<td valign=\"top\">
		<span style=\"background-color: #FFFF00\"><FONT FACE=\"Arial\" size=\"2\">$nopdescr</FONT></span>        
            <input type=\"text\" name=\"pdescr\" size=\"50\" maxlength=\"300\" value=\"$pdescr\">
		</td>
		
	</tr>

	<tr>
		<td>
			<font face=\"Arial\" color=\"$text_color\" size=\"2\">URL:</font>
		</td>
		<td>
		<span style=\"background-color: #FFFF00\"><FONT FACE=\"Arial\" size=\"2\">$nopurl</FONT></span>        
            <input type=\"text\" name=\"purl\" size=\"50\" maxlength=\"200\" value=\"$purl\">
		</td>
		
	</tr>

	<tr>
		<td colspan=\"2\" valign=\"bottom\">
			<input type=\"hidden\" name=\"pid\" value=\"$pid\">
			<input type=\"hidden\" name=\"inscript\" value=\"yes\">
			<input type=\"hidden\" name=\"pkeyword\" value=\"$pkeyword\" >
			<input type=\"hidden\" name=\"products\" value=\"Update Product\">
			<input type=\"submit\" name=\"submit\" value=\"Update Product\">
			</form>
        </td>
	</tr>
	
	</table>
		";
	}
	
	$action_title = "Update Product";

	if($res_msg){
		$results_disp = "
		<tr bgcolor=\"$msgcb_bg_color\">
		<td width=\"100%\">
			<FONT FACE=\"Arial\" COLOR=\"$text_color\" size=\"2\">$res_msg</FONT>&nbsp;
		  </td>
		</tr>";
	} else {
		$results_disp = "<tr><td>&nbsp;</td></tr>";
	}

	$display_form ="
	
	
<table border=\"0\" width=\"100%\" bgcolor=\"$bg_color\">

	<tr>
		<td align=\"left\">
		$action_links
	</td>
	</tr>

		$results_disp

	<tr>
    <td align=\"left\">

  
		$product_list

  </td>
  </tr>
</table>

  ";
  	}//Select Update product end


	//Select Add Product by default
	else {

	

	if($product_list){
		$product_list="			
				$product_list_add	
		";
	}
	
	$action_title = "Add Product";

	if($res_msg){
		$results_disp = "
		<tr bgcolor=\"$msgcb_bg_color\">
		<td width=\"100%\">
			<FONT FACE=\"Arial\" COLOR=\"$text_color\" size=\"2\">$res_msg</FONT>&nbsp;
		  </td>
		</tr>";
	} else {
		$results_disp = "<tr><td>&nbsp;</td></tr>";
	}

	$display_form ="
	
	
<table border=\"0\" width=\"100%\">

 
	<tr>
		<td align=\"left\">
		$action_links
	</td>
	</tr>

		$results_disp

  <tr>
    <td align=\"left\">

    <form method=\"POST\" action=\"sgcb.php\">
	<font face=\"Arial\" color=\"$text_color\" size=\"2\">&nbsp;Find product: </font>
	<input type=\"text\" name=\"pkeyword\" value=\"$pkeyword\" size=\"30\">

	<input type=\"submit\" name=\"submit\" value=\"Go\">
	<HR>
      <table border=\"0\">
	  
	
	<tr>
		<td width=\"100\">
			<font face=\"Arial\" color=\"$text_color\" size=\"2\">Product ID:</font>
		</td>
		<td>
		<span style=\"background-color: #FFFF00\"><FONT FACE=\"Arial\" size=\"2\">$nopid</FONT></span>        
            <input type=\"text\" name=\"pid\" size=\"10\" maxlength=\"10\" value=\"$pid\">
		</td>
		
	</tr>
	<tr>
		<td>
			<font face=\"Arial\" color=\"$text_color\" size=\"2\">Expires in:</font>
		</td>
		<td valign=\"top\">
			<span style=\"background-color: #FFFF00\"><FONT FACE=\"Arial\" size=\"2\">$nopexp</FONT></span>
 			<input type=\"text\" name=\"pexp\" size=\"5\" maxlength=\"5\" value=\"$pexp\">
			&nbsp;&nbsp;<font face=\"Arial\" color=\"$text_color\" size=\"2\">days.</font>
        </td>
		
	</tr>
	<tr>
		<td>
			<font face=\"Arial\" color=\"$text_color\" size=\"2\">Description:</font>
		</td>
		<td valign=\"top\">
		<span style=\"background-color: #FFFF00\"><FONT FACE=\"Arial\" size=\"2\">$nopdescr</FONT></span>        
            <input type=\"text\" name=\"pdescr\" size=\"50\" maxlength=\"300\" value=\"$pdescr\">
		</td>
		
	</tr>
	
	<tr>
		<td>
			<font face=\"Arial\" color=\"$text_color\" size=\"2\">URL:</font>
		</td>
		<td>
		<span style=\"background-color: #FFFF00\"><FONT FACE=\"Arial\" size=\"2\">$nopurl</FONT></span>        
            <input type=\"text\" name=\"purl\" size=\"50\" maxlength=\"200\" value=\"$purl\">
		</td>
	</tr>
	<tr>
		
		<td  valign=\"top\">
			<input type=\"hidden\" name=\"inscript\" value=\"yes\">
			
			<input type=\"hidden\" name=\"products\" value=\"Add Product\">
			<input type=\"submit\" name=\"submit\" value=\"Add Product\">
			
        </td>
		<td >
			&nbsp;
		</td>
	</tr>
	</table>

	<HR>
	<table border=\"0\" width=\"100%\">
	<tr>
		
		<td valign=\"top\">
		
		$product_list
		</td>
	</tr>
	</table>
	
</form>
  </td>
  </tr>
</table>

  ";
  	}//Select Add Product by default end

}//DISPLAY PRODUCTS MANAGEMENT FORM END


//##############################################################################
//##############################################################################




//DISPLAY USER MANAGEMENT FORM

else if($run == "user" && $authorized_user == "admin"){

	$title = "Manage Users";
	$help_id = "users";
	
	
	unset($prod_lists);



$prod_lists=read_products($products_file,$uprod,$text_color,$alt_text_color,$alt_bg_color,$bg_color,$pkeyword);
	

	if($prod_lists){
		$product_list = "
			<select size=\"1\" name=\"uprod\">
			<option value=\"\">Select product from list</option>
			$prod_lists[0]
			</select>";
	} else{
		$product_list ="<FONT FACE=\"Arial\" COLOR=\"$special_text_color\" size=\"2\">Currently no products exist</FONT>";
	}



	$res_msg = urldecode($res_msg);
	$action_links="
		<A HREF=\"sgcb_form.php?run=user&action=add&clear=yes\"><font color=\"$text_color\" face=\"Arial\" size=\"2\">Add User</font></A>
		&nbsp;&nbsp;
		<A HREF=\"sgcb_form.php?run=user&action=del&clear=yes\"><font color=\"$text_color\" face=\"Arial\" size=\"2\">Delete User</font></A>
		&nbsp;&nbsp;
		<A HREF=\"sgcb_form.php?run=user&action=upd&clear=yes\"><font color=\"$text_color\" face=\"Arial\" size=\"2\">Update User</font></A>";

	

	//First read password file if exists
	if(file_exists($users_file)){
		$fd = fopen ($users_file, "r");
		if($fd){$users_info = fread($fd, filesize($users_file));}
		fclose($fd);
	}
	
	//Retrieving users
	if(!$users_info){
		$res_msg .="<FONT COLOR=\"$text_color\" size=\"2\">Currently no users exist</FONT>";
		}
	else{

		//Part of a Search function 1
		if(@eregi($ukeyword,$users_info) && $ukeyword){$usearchword = $ukeyword;}
		//Part of a Search function 1 end

		$users_arr=explode("\n",$users_info);

		//asort($users_arr);
		
		$found_records=0;

		foreach($users_arr as $key=>$val){
			unset($cur_user_ar);
			

			//Part of a Search function 2
			//If search word was specified select only users with matching patterns
			$include="yes";
			if($usearchword){
				if(!eregi($usearchword,$val)){$include = "";}
				else{$found_records++;}
			}
			
			if($include){
			

			$cur_user_ar=explode(":",$val);

				//if entry is not empty
				if($cur_user_ar[0]){

					//Privelege
					if(crypt("admin$cur_user_ar[0]",$cur_user_ar[0]) == $cur_user_ar[2]){
						$upriv_disp = "Admin";
					}
					else if(crypt("user$cur_user_ar[0]",$cur_user_ar[0]) == $cur_user_ar[2]){
						$upriv_disp = "Regular";
					}
					else {$upriv_disp = "REMOVE USER";}
					//Privelege end
					
					//Expiration date
					$uexp_disp = "";
					if($cur_user_ar[5]){

						unset($uexp_arr);
						$uexp_arr = explode("/",$cur_user_ar[5]);
						$uexp_disp = date("d-M-Y",mktime(0,0,0,$uexp_arr[0],$uexp_arr[1],$uexp_arr[2]));

					}
					//Expiration date end

					//Product
					$uprod_disp = $cur_user_ar[4];
					//Product end

					//Real Name
					$urealname_disp = $cur_user_ar[3];
					//Real Name end
					
					//Email
					$uemail_disp = $cur_user_ar[6];
					//Email end

					$current_admin = "";
					
					//Distinguishing between current and all other users
					unset($tmp_current_user);
					$tmp_current_user=explode(":",$current_user);

					if($cur_user_ar[0] == $tmp_current_user[0]){

						$current_admin = "<br>(current)";
						$disp_user="$cur_user_ar[0] -- $urealname_disp -- $uprod_disp -- $uexp_disp -- $uemail_disp -- $upriv_disp (current)";
						
							
						}
					else{
							$disp_user="$cur_user_ar[0] -- $urealname_disp -- $uprod_disp -- $uexp_disp -- $uemail_disp -- $upriv_disp";							
						}
					//Distinguishing between current and all other users end
					
					


					if($disp_user){
						$user_list .= "<option value=\"$cur_user_ar[0]\">$disp_user</option>";
						

						if($curr_bg_color != $alt_bg_color){$curr_bg_color = $alt_bg_color;}
						else {$curr_bg_color = $bg_color;}

						if($upriv_disp == "REMOVE USER" || $upriv_disp == "Admin"){
							$upriv_disp = "<FONT COLOR=\"$special_text_color\">".$upriv_disp."</FONT>";
						}
						$user_list_add .= "
							<tr bgcolor=\"$curr_bg_color\">
							<td align=\"center\"><FONT FACE=\"Arial\" COLOR=\"$alt_text_color\" size=\"2\">$cur_user_ar[0]</FONT>
							</td>
							<td align=\"center\"><FONT FACE=\"Arial\" COLOR=\"$alt_text_color\" size=\"2\">$urealname_disp</FONT>
							</td>
							<td align=\"center\"><FONT FACE=\"Arial\" COLOR=\"$alt_text_color\" size=\"2\">$uprod_disp&nbsp;&nbsp;</FONT>
							</td>
							<td align=\"center\"><FONT FACE=\"Arial\" COLOR=\"$alt_text_color\" size=\"2\">$uexp_disp&nbsp;&nbsp;</FONT>
							</td>
							<td align=\"center\"><FONT FACE=\"Arial\" COLOR=\"$alt_text_color\" size=\"2\"><a href=\"mailto:$uemail_disp\">$uemail_disp</a>&nbsp;&nbsp;</FONT>
							</td>
							<td align=\"center\"><FONT FACE=\"Arial\" COLOR=\"$alt_text_color\" size=\"2\">$upriv_disp&nbsp;&nbsp;<FONT COLOR=\"$special_text_color\">$current_admin</FONT></FONT>
							</td>
							</tr>";
						
					}
				}//if entry is not empty end
	
			//Part of a Search function 3
			}//If search word was specified select only users with matching patterns end
			

		}//foreach end
		
		
		$user_list_add = "
			<TABLE WIDTH=\"100%\">
			<TR>
				<TD align=\"center\"><FONT FACE=\"Arial\" COLOR=\"$text_color\" size=\"2\">
				<B>Username</B>
				</FONT></TD>
				<TD align=\"center\"><FONT FACE=\"Arial\" COLOR=\"$text_color\" size=\"2\">
				<B>Real Name</B>
				</FONT></TD>
				<TD align=\"center\"><FONT FACE=\"Arial\" COLOR=\"$text_color\" size=\"2\">
				<B>Product</B>
				</FONT></TD>
				<TD align=\"center\"><FONT FACE=\"Arial\" COLOR=\"$text_color\" size=\"2\">
				<B>Expiration</B>
				</FONT></TD>
				<TD align=\"center\"><FONT FACE=\"Arial\" COLOR=\"$text_color\" size=\"2\">
				<B>Email</B>
				</FONT></TD>
				<TD align=\"center\"><FONT FACE=\"Arial\" COLOR=\"$text_color\" size=\"2\">
				<B>Admin</B>
				</FONT></TD>
				
			</TR>
			$user_list_add
			</TABLE>
		";

		
		if($ukeyword && $res_msg == ""){
			if($found_records > 0){
				$res_msg .= "Total <B>$found_records</B> users containing <B>\"$ukeyword\"</B> found";
			} else{
				$res_msg .= "No users containing <B>\"$ukeyword\"</B> found";
			}
		
		}
		//Part of Search function 3 end

	}//Retrieving users end

		//Delete user selected
		if($action == "del"){
	

		if($user_list){
			$user_list = "<font face=\"Arial\" color=\"$text_color\" size=\"2\">Select users from the list:<BR><B>Username -- Real Name -- Product -- Expiration -- Email -- User Type</B><br></font>
				<select size=\"10\" name=\"udelete_list[]\" multiple>
    			$user_list
				<option value=\"*DELETE ALL USERS*\">*DELETE ALL USERS*</option>
				</select>";

			$delete_form = "

			<form method=\"POST\" action=\"sgcb.php\">

			<!-- Part of a Search function 4 -->
			<font face=\"Arial\" color=\"$text_color\" size=\"2\">&nbsp;Find user: </font>
			<input type=\"text\" name=\"ukeyword\" value=\"$ukeyword\" size=\"30\">

			<input type=\"submit\" name=\"submit\" value=\"Go\">
			<hr>
			<!-- Part of a Search function 4 end -->

			  <table border=\"0\">
			  
			 
			<tr>
				<td colspan=\"2\">
				$user_list
				</td>
			</tr>
			<tr>
				<td colspan=\"2\" valign=\"top\">
					<font face=\"Arial\" color=\"$text_color\" size=\"2\">or type comma-separated usernames:</font><br>
					<input type=\"hidden\" name=\"user\" value=\"Delete User\">
				  <input type=\"text\" name=\"ualt_delete\" size=\"45\">
					
					<input type=\"hidden\" name=\"inscript\" value=\"yes\">
					
					&nbsp;&nbsp;<input type=\"submit\" name=\"submit\" value=\"Delete User\">
					
				</td>
				<td>&nbsp;
				</td>
			</tr>


			
			</table>
			</form>
			";
		}

	//Finalizing delete list

	$action_title = "Delete User";

	if($res_msg){
		$results_disp = "
		<tr bgcolor=\"$msgcb_bg_color\">
		<td width=\"100%\">
			<FONT FACE=\"Arial\" COLOR=\"$text_color\" size=\"2\">$res_msg</FONT>&nbsp;
		  </td>
		</tr>";
	} else {
		$results_disp = "<tr><td>&nbsp;</td></tr>";
	}

	$display_form ="
	
	
<table border=\"0\" width=\"100%\">

	<tr>
		<td align=\"left\">
		$action_links
	</td>
	</tr>
	
		$results_disp

	<tr>
    <td align=\"left\">

    $delete_form

  </td>
  </tr>
</table>

  ";

	
	
	}//Delete user selected end


//################
//################



//Select Update  user 
	else if($action=="upd" || $action=="sel") {


	if($upriv == "admin"){$admin_slctd = "selected";}

	if($user_list){
		$user_list="
			
		<form method=\"POST\" action=\"sgcb.php\">

		<!-- Part of a Search function 5 -->
		<font face=\"Arial\" color=\"$text_color\" size=\"2\">&nbsp;Find user: </font>
		<input type=\"text\" name=\"ukeyword\" value=\"$ukeyword\" size=\"30\">
		<input type=\"submit\" name=\"submit\" value=\"Go\">
		<HR>
		<!-- Part of a Search function 5 end -->

		<table border=\"0\">
		<tr>
			<td colspan=\"2\">
			
			<TABLE>
			<TR>
				<TD valign=\"top\">
					
					<font face=\"Arial\" color=\"$text_color\" size=\"2\">Select User To Update<br><B>Username -- Real Name -- Product -- Expiration -- Email -- User Type</B><br></font>
					<select size=\"9\" name=\"upd_usr[]\">
					$user_list
					</select>
				</TD>
			</TR>
			<TR>
				<TD valign=\"top\">
					<input type=\"hidden\" name=\"inscript\" value=\"yes\">
					<input type=\"hidden\" name=\"user\" value=\"Select User\">
					
					<input type=\"submit\" name=\"submit\" value=\"Select User\">
				</TD>
			</TR>
			</TABLE>
			
			</form>
				
			</td>
		</tr>

		<tr>
		<td> <form method=\"POST\" action=\"sgcb.php\" name=\"userform\">		
			<font face=\"Arial\" color=\"$text_color\" size=\"2\">Username:</font>
		</td>
		<td>   
            <font face=\"Arial\" color=\"$text_color\" size=\"2\"><B>$uusername</B></font>
			
		</td>
		
	</tr>
	<tr>
		<td>
			<font face=\"Arial\" color=\"$text_color\" size=\"2\">Password:</font>
		</td>
		<td valign=\"top\">
			<span style=\"background-color: #FFFF00\"><FONT FACE=\"Arial\" size=\"2\">$noupass</FONT></span>
 			<input type=\"password\" name=\"upass\" size=\"30\" maxlength=\"30\" value=\"$upass\">
        </td>
		
	</tr>
	<tr>
		<td>
			<font face=\"Arial\" color=\"$text_color\" size=\"2\">Real name:</font>
		</td>
		<td valign=\"top\">
		<span style=\"background-color: #FFFF00\"><FONT FACE=\"Arial\" size=\"2\">$nourealname</FONT></span>        
            <input type=\"text\" name=\"urealname\" size=\"30\" maxlength=\"30\" value=\"$urealname\">
		</td>
		
	</tr>
	<tr>
		<td>
			<font face=\"Arial\" color=\"$text_color\" size=\"2\">Email:</font>
		</td>
		<td valign=\"top\">
		<span style=\"background-color: #FFFF00\"><FONT FACE=\"Arial\" size=\"2\">$nouemail</FONT></span>        
            <input type=\"text\" name=\"uemail\" size=\"30\" maxlength=\"100\" value=\"$uemail\">
		</td>
		
	</tr>
	<tr>
		<td>
			<font face=\"Arial\" color=\"$text_color\" size=\"2\">Associated product:</font>
		</td>
		<td valign=\"top\">
		<span style=\"background-color: #FFFF00\"><FONT FACE=\"Arial\" size=\"2\">$nouprod</FONT></span> 
					
			$product_list

		</td>
		
	</tr>
	<tr>
		<td >
		<font face=\"Arial\" size=\"2\" color=\"$text_color\">
		User expiration date:
		</font>	
		</td>
		<td ><span style=\"background-color: #FFFF00\"><FONT FACE=\"Arial\" size=\"2\">$nouexp</FONT></span> 		
		<input type=\"text\" name=\"uexp\" size=\"15\" value=\"$uexp\"><a href=\"javascript:show_calendar('userform.uexp');\" onmouseover=\"window.status='Select Expiration Date';return true;\" onmouseout=\"window.status='';return true;\"><img src=\"images\show-calendar.gif\" width=24 height=22 border=0></a>&nbsp;<font face=\"Arial\" size=\"2\" color=\"$text_color\">
		(leave blank if the same as product expiration)
		</font>	
		</td>
	</tr>
	<tr>
		<td>
			<font face=\"Arial\" color=\"$text_color\" size=\"2\">User type:</font>
		</td>
		<td>
		<span style=\"background-color: #FFFF00\"><FONT FACE=\"Arial\" size=\"2\">$noupriv</FONT></span>        
		<select size=\"1\" name=\"upriv\">
			<option value=\"regular\" $reg_slctd>Regular User</option>
			<option value=\"admin\" $admin_slctd>Admin</option>
		</select>
		</td>
		
	</tr>
	<tr>
		<td>
			<input type=\"hidden\" name=\"uusername\" value=\"$uusername\">
			<input type=\"hidden\" name=\"uoldpass\" value=\"$upass\">
			<input type=\"hidden\" name=\"inscript\" value=\"yes\">
			
			<!-- Part of a Search function 6 -->
			<input type=\"hidden\" name=\"ukeyword\" value=\"$ukeyword\" >
			<!-- Part of a Search function 6 end -->

			<input type=\"hidden\" name=\"user\" value=\"Update User\">
			<input type=\"submit\" name=\"submit\" value=\"Update User\">
		</td>
		<td>
		&nbsp;
			
		</td>
		
	</tr>
	
	</table></form>
		";
	}
	
	$action_title = "Update User";

	if($res_msg){
		$results_disp = "
		<tr bgcolor=\"$msgcb_bg_color\">
		<td width=\"100%\">
			<FONT FACE=\"Arial\" COLOR=\"$text_color\" size=\"2\">$res_msg</FONT>&nbsp;
		  </td>
		</tr>";
	} else {
		$results_disp = "<tr><td>&nbsp;</td></tr>";
	}

	$display_form ="
	
	
<table border=\"0\" width=\"100%\" bgcolor=\"$bg_color\">

	<tr>
		<td align=\"left\">
		$action_links
	</td>
	</tr>

		$results_disp

	<tr>
    <td align=\"left\">

  
		$user_list

  </td>
  </tr>
</table>

  ";
  	}//Select update user end


	//Select Add user by default
	else {

	
	


	if($user_list){
		$user_list_add="
			$user_list_add	
		";
	}
	
	$action_title = "Add User";

	if($res_msg){
		$results_disp = "
		<tr bgcolor=\"$msgcb_bg_color\">
		<td width=\"100%\">
			<FONT FACE=\"Arial\" COLOR=\"$text_color\" size=\"2\">$res_msg</FONT>&nbsp;
		  </td>
		</tr>";
	} else {
		$results_disp = "<tr><td>&nbsp;</td></tr>";
	}

	if($upriv == "admin"){$admin_slctd = "selected";}

	$display_form ="
	
	
<table border=\"0\" width=\"100%\">

 
	<tr>
		<td align=\"left\">
		$action_links
	</td>
	</tr>

		$results_disp

  <tr>
    <td align=\"left\">

    <form method=\"POST\" action=\"sgcb.php\" name=\"userform\">

	<!-- Part of a Search function 7 --!>
	<font face=\"Arial\" color=\"$text_color\" size=\"2\">&nbsp;Find user: </font>
	<input type=\"text\" name=\"ukeyword\" value=\"$ukeyword\" size=\"30\">
	<input type=\"submit\" name=\"submit\" value=\"Go\">
     <HR>
	<!-- Part of a Search function 7 end --!>

	  <table border=\"0\">
	  
	
	<tr>
		<td>
			<font face=\"Arial\" color=\"$text_color\" size=\"2\">Username:</font>
		</td>
		<td>
		<span style=\"background-color: #FFFF00\"><FONT FACE=\"Arial\" size=\"2\">$nouusername</FONT></span>        
            <input type=\"text\" name=\"uusername\" size=\"30\" maxlength=\"30\" value=\"$uusername\">
		</td>
		
	</tr>
	<tr>
		<td>
			<font face=\"Arial\" color=\"$text_color\" size=\"2\">Password:</font>
		</td>
		<td>
			<span style=\"background-color: #FFFF00\"><FONT FACE=\"Arial\" size=\"2\">$noupass</FONT></span>
 			<input type=\"password\" name=\"upass\" size=\"30\" maxlength=\"30\" value=\"$upass\">
        </td>
		
	</tr>
	<tr>
		<td>
			<font face=\"Arial\" color=\"$text_color\" size=\"2\">Real name:</font>
		</td>
		<td>
		<span style=\"background-color: #FFFF00\"><FONT FACE=\"Arial\" size=\"2\">$nourealname</FONT></span>        
            <input type=\"text\" name=\"urealname\" size=\"30\" maxlength=\"30\" value=\"$urealname\">
		</td>
		
	</tr>
	<tr>
		<td>
			<font face=\"Arial\" color=\"$text_color\" size=\"2\">Email:</font>
		</td>
		<td valign=\"top\">
		<span style=\"background-color: #FFFF00\"><FONT FACE=\"Arial\" size=\"2\">$nouemail</FONT></span>        
            <input type=\"text\" name=\"uemail\" size=\"30\" maxlength=\"100\" value=\"$uemail\">
		</td>
		
	</tr>
	
	<tr>
		<td>
			<font face=\"Arial\" color=\"$text_color\" size=\"2\">Associated product:</font>
		</td>
		<td valign=\"top\">
		<span style=\"background-color: #FFFF00\"><FONT FACE=\"Arial\" size=\"2\">$nouprod</FONT></span> 
					
			$product_list

		</td>
		
	</tr>
	<tr>
		<td >
		<font face=\"Arial\" size=\"2\" color=\"$text_color\">
		User expiration date:
		</font>	
		</td>
		<td ><span style=\"background-color: #FFFF00\"><FONT FACE=\"Arial\" size=\"2\">$nouexp</FONT></span> 		
		<input type=\"text\" name=\"uexp\" size=\"15\" value=\"$uexp\"><a href=\"javascript:show_calendar('userform.uexp');\"  onmouseover=\"window.status='Select Expiration Date';return true;\" onmouseout=\"window.status='';return true;\"><img src=\"images\show-calendar.gif\" width=24 height=22 border=0 ></a>&nbsp;<font face=\"Arial\" size=\"2\" color=\"$text_color\">
		(leave blank if the same as product expiration)
		</font>	
		</td>
	</tr>
	<tr>
		<td valign=\"bottom\">
			<font face=\"Arial\" color=\"$text_color\" size=\"2\">User type:</font>
		</td>
		<td >
		<select size=\"1\" name=\"upriv\">
			<option value=\"regular\" $reg_slctd>Regular User</option>
			<option value=\"admin\" $admin_slctd>Admin</option>
		</select>
		
        </td>
	</tr>
	<tr>
		<td valign=\"bottom\">
			<input type=\"hidden\" name=\"inscript\" value=\"yes\">
			<input type=\"hidden\" name=\"user\" value=\"Add User\">
			<input type=\"submit\" name=\"submit\" value=\"Add User\">
		</td>
		<td >
			&nbsp;		
        </td>
	</tr>
	</table>
	<HR>
	$user_list_add
	</form>

  </td>
  </tr>
</table>

  ";
  	}//Select add user by default end

}//DISPLAY USER MANAGEMENT FORM END


//##############################################################################
//##############################################################################


//Welcome message
else if($run == "message" && $authorized_user == "admin"){

	$help_id="home";

	//Extract Username and Real user's name from current_user
	unset($tmp_current_user);
	$tmp_current_user=explode(":",$current_user);

	if(!$tmp_current_user[1]){$current_user_disp=$tmp_current_user[0];}
	else {$current_user_disp=$tmp_current_user[1];}


		$action_title = "Welcome $current_user_disp!";

		$display_form = "
			<table border=\"0\" width=\"100%\" >

			
			<tr>
				<td>
				<FONT FACE=\"Arial\" size=\"2\" COLOR=\"$text_color\">
				Thank you for using Sales Guard CB!<BR><BR>
				The following checklist may help you to start using this program quickly:
				<OL>
					<LI>Change Administrator's password or create a new user with administrative priveleges (click \"Users\" link).<BR><BR>
					
					<LI>Create products (click \"Products\" link).<BR><BR>
					
					<LI>Change settings to include your <B><I>Secret Code</I></B> from Clickbank as well as your contact information (click \"Settings\" link).<BR><BR>
					
					<LI>Go to your Clickbank account and put URL of \"<B>sgcb.php</B>\" in one of a product slots (for example slot #1).<BR><BR>
					
					<LI>Go to your sales pages and change your product links to include your newly created product IDs in \"<B><I>seed</I></B>\" variable <BR><BR>(for example: <FONT  COLOR=\"$alt_text_color\">http://www.clickbank.net/sell.cgi?link=seller/<B>1</B>/test&seed=<B>yourproductid</B></FONT>).<BR><BR>All your product links may refer to the same product slot (if they have the same price) in Clickbank which you created in previous paragraph (in this example this is slot #1). 
					
				</OL>
				REMINDER:<BR><FONT COLOR=\"$special_text_color\">Please make sure your downloadable files have non-displayable extentions (like \"<B>ZIP</B>\" or \"<B>EXE</B>\").  DO NOT use files with \"HTML\", \"TXT\", \"PDF\" or any other extentions which may revel true download URL of your products.</FONT><BR><BR>
				
				If you need assistance a help link is always available for every screen.<BR><BR>We hope you'll enjoy this experience!<BR><BR><FONT  COLOR=\"$alt_text_color\"><I>Management of Software Programs, Inc.</I></FONT></FONT>
				</td>
			</tr>
			</table>";

}//Welcome message end



//##############################################################################
//##############################################################################

//SET MENU OPTIONS 
if($authorized_user == "admin"){
	//Display main menu
	
	$menu ="

<table cellpadding=\"1\" cellspacing=\"1\" width=\"104\">

<tr>
	<td>
		<a href=\"sgcb_form.php?run=message\"><font color=\"$text_color\" face=\"Arial\" size=\"2\">Home</font></a>
		
	</td>
</tr>

<tr>
	<td>
	<a href=\"$install_dir/sgcb_form.php?run=products\"><font color=\"$text_color\" face=\"Arial\" size=\"2\"> Products</font></a>
	</td>
</tr>
<tr>
	<td>
	<a href=\"$install_dir/sgcb_form.php?run=user&clear=yes\"><font color=\"$text_color\" face=\"Arial\" size=\"2\"> Users</font></a>
	</td>
</tr>
<tr>
	<td>
	<a href=\"$install_dir/sgcb_form.php?run=settings\"><font color=\"$text_color\" face=\"Arial\" size=\"2\"> Settings</font></a>
	</td>
</tr>
<tr>
	<td>
		<a href=\"javascript: sgcb_help=window.open('$install_dir/sgcb_help.php?help_id=$help_id','sgcb_help','width=570,height=450,toolbar=yes,scrollbars=yes, resizable=yes,top=80,left=260');sgcb_help.focus();void('');\"><font color=\"$text_color\" face=\"Arial\" size=\"2\">Help</font></a>
		<br><BR>
	</td>
</tr>
<tr>
	<td>
		<a href=\"sgcb_form.php\"><font color=\"$special_text_color\" face=\"Arial\" size=\"2\">Logout</font></a>
	</td>
</tr>
</table>
";
//Display main menu end

}

//SET MENU OPTIONS END 


//##############################################################################
//##############################################################################


if(!$session_array_sgcb[authorized_user]){

	$quit="yes";
}

}//SECURITY CHECK END ###############################################################

//FORCE UNAUTHORIZED USER TO QUIT
else {
	$quit="yes";
} 

//LOGOUT
if(!$run){
	$quit="yes";
} 


//ACTUAL QUIT SEQUENCE
if($quit){

	unset($session_array_sgcb);

	header("Location: $login_page");
	exit;
}
//ACTUAL QUIT SEQUENCE END

//##################### CONSTRUCTING FORMS END #####################


//Extract Username and Real user's name from current_user
unset($tmp_current_user);
$tmp_current_user=explode(":",$current_user);

if(!$tmp_current_user[1]){$current_user_disp="$tmp_current_user[0]";}
else {$current_user_disp="$tmp_current_user[1]";}

if($run == "message"){$current_user_disp="";}

if($run == "thankyoupage"){
	
	$display_form = $user_display_form."<TR>
		<TD colspan=\"2\" align=\"center\">";

	$current_user_disp = "";

} else{
	
	$display_form = "
	<TR>
		<TD valign=\"top\" width=\"104\">$menu</TD>
		<TD valign=\"top\" bgcolor=\"$bg_color\">$display_form</TD>
	</TR>
	<TR><TD valign=\"top\" width=\"104\"></TD>
		<TD align=\"center\">
	";
}

//Creating home link
$home_link = "<A HREF=\"$home_url\"><B><FONT FACE=\"Arial\" SIZE=\"2\" COLOR=\"$text_color\">Back to Home Page</FONT></B></A>";

//DISPLAY PAGE
echo "
<html>
<head>
<title>$maintitle</title>
<script language=\"JavaScript\" src=\"sgcb_date.js\"></script>
</head>

<body >




$company_logo

<table width=\"100%\">
<tr>
	<td style=\"BORDER-TOP: #495378 2px solid; BORDER-BOTTOM: #495378 2px solid\">
	
		<TABLE width=\"100%\" bgcolor=\"$title_bg_color\">
		<TR>
			<TD width=\"104\" align=\"center\">
				<IMG SRC=\"images/sgcb_logo.jpg\" WIDTH=\"104\" HEIGHT=\"78\" BORDER=0 ALT=\"Sales Guard CB\">
			</TD>
			<TD align=\"center\">
			
			<TABLE width=\"100%\">
			<TR>
				<TD align=\"center\">
				<font color=\"$title_color\" face=\"Arial\" size=\"4\"><B>$action_title</B></font>
				</TD>
			</TR>
			<TR>
				<TD align=\"center\">
				<font color=\"$current_user_color\" face=\"Arial\" size=\"2\">$current_user_disp</font>
				</TD>
			</TR>
			</TABLE>
			
			</TD>
		</TR>
		</TABLE>

	</td>
</tr>

<tr>
	<td  valign=\"top\">
	<TABLE width=\"100%\" >
	$display_form
	<BR>
	$home_link<BR><BR>
	<FONT SIZE=\"1\" FACE=\"Arial\" COLOR=\"$text_color\">Security provided by: <a href=\"http://www.software-programs.net\"><FONT SIZE=\"1\" FACE=\"Arial\" COLOR=\"$special_text_color\">Software Programs, Inc.</FONT></a><BR>&copy; Copyright 2002 - 2003. - Houston, TX USA - All rights reserved.</FONT></TD>
		
	</TR>
	</TABLE>

	</td>

</tr>

</table>
</body>
</html>
";
?>