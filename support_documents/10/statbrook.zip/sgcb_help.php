<?
//##################################################################################
//SALES GUARD CB HELP UTILITY
//SGCB_HELP.PHP 
//
//
//March 21, 2002
//Software Programs, Inc.  Copyright 2002 - 2003. - Houston, TX USA - All rights reserved.
//www.software-programs.net
//
//License:	Unlimited installations permitted.  Product modifications allowed.  
//			Redistribution prohibited without written approval. 
//
//##################################################################################
//
//REQUIREMENTS: Apache, PHP4



//<START CUT HERE>

if($help_id == "home"){

$display_form = "
<p><b><font face=\"Arial\" size=\"4\" color=\"#008000\">How does
      this work?</font><font face=\"Arial\" size=\"4\" color=\"#FF0000\"><br>
      </font></b><font face=\"Arial\" color=\"#000080\" size=\"2\">Sales Guard CB</font><font face=\"Arial\" color=\"#000080\" size=\"2\">
has been
      designed to allow Clickbank merchants dynamically create &quot;Thank You&quot; pages with
the expiration dates for multiple downloadable
      files.&nbsp; While actual downloadable files can be located on
      different domains (as well as sales pages), merchant needs only one
      Clickbank account.&nbsp; The core idea behind Sales Guard CB is to give a buyer of a product limited time for download to prevent
      possible abuse and free distribution.&nbsp; This is achieved by creating a
      personal account for each buyer which expires after certain time
      associated with the purchased product.&nbsp; Actual URL of a downloadable
      file is hidden from the buyer.&nbsp; Therefore as soon as his or her time
      expires buyer has no knowledge of where the file is located and can not download
      it again. </font></p>
      <p><font color=\"#FF0000\"><b><font face=\"Arial\" size=\"2\">IMPORTANT:</font></b><font face=\"Arial\" size=\"2\">
      Sales Guard CB is intended to provide access to DOWNLOADABLE files and not to
      create access to protected areas.&nbsp; Actual file directory is not meant
      to be disclosed to buyers.&nbsp; Therefore all downloadable files should
      be non-displayable by browser (like &quot;<b>zip</b>&quot; or &quot;<b>exe</b>&quot;).</font></font></p>
      <p><b><font face=\"Arial\" size=\"4\" color=\"#008000\">Details of the sale
      process</font></b><font face=\"Arial\" color=\"#000080\" size=\"2\"><br>
      First, buyer clicks a sales link on merchant's sales page.&nbsp; This link
      is well-described on <a href=\"http://www.clickbank.com/crypto.html\" target=\"_blank\">Clickbank's
      documentation</a> page and looks like this:</font></p>
      <p><font face=\"Arial\" color=\"#000080\" size=\"2\">&nbsp;</font><font face=\"Arial\" size=\"2\" color=\"#008080\">http://www.clickbank.net/sell.cgi?link=seller/1/test&amp;<b>seed</b>=</font><b><font face=\"Arial\" size=\"2\" color=\"#FF00FF\">yourproductid</font></b></p>
      <p><font face=\"Arial\" color=\"#000080\" size=\"2\">Sales Guard CB</font><font face=\"Arial\" color=\"#000080\" size=\"2\">
      utilizes </font><font face=\"Arial\" color=\"#000080\" size=\"3\"><b><i>seed</i></b></font><font face=\"Arial\" color=\"#000080\" size=\"2\">
      variable to pass your product ID from sales page to Sales Guard CB's
      &quot;Thank You&quot; page after purchase was
      made.&nbsp; Product ID tells Sales Guard CB to which product buyer must have access
      (product ID created in Sales Guard CB has to be the same as in the
      link).</font></p>
      <p><font face=\"Arial\" color=\"#000080\" size=\"2\">After buyer clicked the
      link he/she is taken through credit card authorization process.&nbsp;
      If everything is fine buyer will be redirected to &quot;Thank You&quot;
      page.&nbsp; The URL of a &quot;Thank You&quot; page is defined in
      merchant's Clickbank account.&nbsp; This URL has to lead to Sales Guard CB's
      main file </font><font face=\"Arial\" color=\"#000080\" size=\"3\"><b>sgcb.php</b></font><font face=\"Arial\" color=\"#000080\" size=\"2\">.&nbsp;
      The &quot;Thank You&quot; URL setup area looks like this:</font></p>
      <hr>
      <font color=\"#008080\">
      <font face=\"verdana\" size=\"-1\"><b>THANK-YOU PAGES</b><br></font><input maxLength=\"120\" size=\"33\" value=\"http://www.domain.com/sgcb/sgcb.php\" name=\"payurl1\">
      <input maxLength=\"8\" size=\"7\" value=\"$34.95\" name=\"price1\">  URL &amp;
      Price of page 1<br>
      <input maxLength=\"120\" size=\"33\" value=\"http://www.domain.com/sgcb/sgcb.php\" name=\"payurl1\">
      <input maxLength=\"8\" size=\"7\" value=\"$19.95\" name=\"price1\">   URL &amp;
      Price of page 2</font><br>
      &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
      ....&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
      ....&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
      ....&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
      ....<br>
      <font face=\"Arial\" color=\"#000080\" size=\"2\">
      <br>
      If you've noticed URL is the same for both products 1 and 2.&nbsp; This is
      because product ID has already been passed to </font><font face=\"Arial\" color=\"#000080\" size=\"3\"><b>sgcb.php</b></font><font face=\"Arial\" color=\"#000080\" size=\"2\">
      in </font><b><i><font face=\"Arial\" color=\"#000080\" size=\"3\">seed</font></i></b><font face=\"Arial\" color=\"#000080\" size=\"2\">
      variable.&nbsp; Products are described in Sales Guard CB and have attributes
      (Product ID, Expiration, Description and URL). </font>
      <p><font face=\"Arial\" color=\"#000080\" size=\"2\">&nbsp;As soon as control is
      passed from Clickbank to </font><font face=\"Arial\" color=\"#000080\" size=\"3\"><b>sgcb.php</b></font><font face=\"Arial\" color=\"#000080\" size=\"2\">
      and Sales Guard CB determined that the purchase was authentic, product ID is
      recovered from </font><b><i><font face=\"Arial\" color=\"#000080\" size=\"3\">seed</font></i></b><font face=\"Arial\" color=\"#000080\" size=\"2\">
      variable and product attributes are used to create a new user
      account.&nbsp; Only one product is associated with each buyer's
      account.&nbsp; </font></p>
      <p><font face=\"Arial\" color=\"#000080\" size=\"2\">A &quot;Thank You&quot;
      page with a download button is immediately displayed to the buyer.&nbsp; Buyer
      will see his/her username and password and will be given the opportunity
      to receive them by e-mail (Sales Guard CB may keep a log of people who
      provided their names and e-mails.&nbsp; This makes possible to create
      different mailing lists).&nbsp; After buyer downloads purchased product he/she
      is immediately logged off.&nbsp; This is done for security
      purposes.&nbsp; Buyer can re-login and download purchased product as many
      times as needed until his or her account expires.&nbsp; After expiration
      buyer's account is automatically deleted.<br>
      <br>
      <img border=\"0\" src=\"images/sgcb_diagram.jpg\" width=\"370\" height=\"314\">
      </font></p>
      ";}
      
else if($help_id == "products"){

$display_form = "
      
<p><b><font face=\"Arial\" size=\"4\" color=\"#008000\">Creating Products in Sales Guard CB</font></b><font face=\"Arial\" color=\"#000080\" size=\"2\"><br>
Every product in Sales Guard CB has four parameters: <b>Product ID, Expiration,
Description</b> and <b>Download URL</b>.&nbsp; Only <b>Product ID</b> and <b>Download
URL</b> are required parameters.&nbsp;&nbsp;</font></p>
<p><font face=\"Arial\" size=\"2\" color=\"#000080\">Characters: </font><b><font face=\"Arial\" size=\"2\" color=\"#000080\"><span style=\"background-color: #FFFFCC\">(&quot;)
- double quotes, (') - single quotes, (/) - slash, (\) - backslash, (,) - comma,
(&lt;) - less then, (&gt;) - greater then, (&lt;...&gt;) - HTML tags, WHITE
SPACES</span> </font></b><font face=\"Arial\" size=\"2\" color=\"#000080\">are
prohibited and will be automatically deleted from input.&nbsp;&nbsp;</font></p>
<p><font face=\"Arial\" size=\"2\" color=\"#000080\">The most important attention must
be paid to assigning product a Download URL.&nbsp; This URL should not be
protected by password, so that buyers could have immediate download possibility
when they click &quot;Download Now&quot; button.&nbsp; The only protection for
download URLs remains secrecy - buyers should never be shown that URL.&nbsp; On
the &quot;Thank You&quot; page a button <input type=\"submit\" value=\"Download Now\" name=\"thankyoupage\">
is displayed.&nbsp; Even if buyer will look in the source he/she will not see
actual URL of the product - only location of Sales Guard CB.</font></p>
<p><font face=\"Arial\" size=\"2\" color=\"#000080\">The only way the URL can be
exposed if it takes the user to a displayable type of file like HTML or PDF and so
on.&nbsp; Therefore all your files have to be of types which initiate download
process such as &quot;ZIP&quot; or &quot;EXE&quot;.&nbsp; </font><span style=\"background-color: #FFFFCC\"><font face=\"Arial\" size=\"2\" color=\"#FF0000\"><b>For
that reason it is always recommended to use archived files in Download URL.</b></font></span></p>


<p><font face=\"Arial\" size=\"2\" color=\"#000080\">Your actual download URLs can be located
anywhere.&nbsp; Here are some examples:</font></p>


<p><font face=\"Arial\" size=\"2\" color=\"#008000\">http://www.OneOfYourDomains.com/SeretDownloadsDirectory/YourProduct1.zip<br>
http://www.OneOfYourDomains.com/SeretDownloadsDirectory/YourProduct2.zip<br>
http://www.AnotherDomainOfYours.net/SeretDownloadsDirectory/YourProduct3.exe</font></p>


";}
      
else if($help_id == "users"){

$display_form = "


<p><b><font face=\"Arial\" size=\"4\" color=\"#008000\">Creating Users in Sales Guard CB</font></b><font face=\"Arial\" color=\"#000080\" size=\"2\"><br>
<b>REGULAR USERS</b><br>
Most of the users will be created automatically when the sale is made.&nbsp; When
buyer is taken to Sales Guard CB after payment a new Username is created with the
same value as a receipt, issued by Clickbank.&nbsp; At the same time user is
given expiration date (defined in the product's properties) and a random
password.&nbsp; If user elected to receive it Username and&nbsp; Password by
e-mail, his real name and e-mail will also be captured.&nbsp; This kind of user
is automatically given type of &quot;Regular user&quot;.&nbsp;&nbsp;</font></p>
<p><font face=\"Arial\" color=\"#000080\" size=\"2\"><b>ADMIN<br>
</b>Only administrative user can change anything in the program.&nbsp; Every
Regular User can become Admin if it's type changed to &quot;Admin&quot;.&nbsp;
Therefore administrator should be careful not to give administrative privileges
to regular customers.</font></p>
<p><font face=\"Arial\" color=\"#000080\" size=\"2\">All users are automatically
deleted when their expiration date comes.&nbsp; If an expiration date is not
assigned manually it is taken from the product associated with the user (manually
set expiration date takes precedence over date associated with the product).&nbsp;
If no product is associated with the user and no expiration date is set, the user is
never removed.</font></p>
<p><font face=\"Arial\" color=\"#000080\" size=\"2\"><b>Deleting users:</b> If you
select *DELETE ALL USERS* option, all users will be deleted except Current
Admin. Current Admin can not deprive himself from administrative privilege.&nbsp;
These two precautions prevent accidental lockout.</font></p>

";}
      
else if($help_id == "settings"){

$display_form = "

<p><b><font face=\"Arial\" size=\"4\" color=\"#008000\">Settings</font></b><font face=\"Arial\" color=\"#000080\" size=\"2\"><br>
<span style=\"background-color: #FFFFCC\">The main setting which </span></font><span style=\"background-color: #FFFFCC\"><font face=\"Arial\" color=\"#FF0000\" size=\"2\"><b>HAS
TO BE SET</b></font><font face=\"Arial\" color=\"#000080\" size=\"2\"> is a <b>Secret
Key</b>.</font></span><font face=\"Arial\" color=\"#000080\" size=\"2\">&nbsp;&nbsp;&nbsp;
It is the same key as the merchant has set in the Clickbank account.&nbsp; If
these keys
are not the same &quot;Thank You&quot; pages will never be displayed to all
buyers.</font></p>
<p><font face=\"Arial\" color=\"#000080\" size=\"2\">If <b>Name of a contact</b> and <b>Contact
email</b> variables are set, then a message informing buyers about who to contact
with questions is displayed in both &quot;Thank You&quot; page and email
message.&nbsp; These variables have to be either both set or both clear.&nbsp;
Therefore error message will be displayed if one of them is missing.</font></p>
<p><font face=\"Arial\" color=\"#000080\" size=\"2\">If <b>Keep log</b> checkbox is
checked, Sales Guard CB will keep records of users who provided their real names and
e-mails on the &quot;Thank You&quot; page.&nbsp; If the log already exists several
more links will be shown, allowing administrator to see the log and create mailing
lists.&nbsp; <b>Master mail list</b> allows administrator to generate a list of
unique e-mails ready to be cut and pasted in any mail program into
&quot;To:&quot; field.&nbsp; <b>Mail lists by product</b> generates multiple
lists of unique emails for each product which has been purchased.</font></p>
<p><font face=\"Arial\" color=\"#000080\" size=\"2\">Checkbox <b>Force e-mail collection</b>
reorganizes the &quot;Thank You&quot; page to force customer enter his / her
e-mail information.&nbsp; Download link will not be displayed to customer until
e-mail information is completed.&nbsp;&nbsp;</font></p>
<p><span style=\"background-color: #FFFFCC\"><b><font face=\"Arial\" size=\"2\" color=\"#FF0000\">WARNING</font></b><font face=\"Arial\" color=\"#000080\" size=\"2\">:
According to Clickbank's rules merchant is expected to take customer directly to
download page without making him / her to enter any additional
information.&nbsp; Use of this option may be considered unethical by Clickbank.</font></span><font face=\"Arial\" color=\"#000080\" size=\"2\">&nbsp;&nbsp;</font></p>
";}

//<END CUT HERE>


else {
	$close_directive = "<script language=\"JavaScript\">window.close();</script>";
}

echo "

<html>
<head>
<title>Sales Guard CB Help</title>
</head>
<body>

$close_directive

<table border=\"0\" width=\"100%\">
  <tr>
    <td width=\"100%\" bgcolor=\"#000080\">
      <p align=\"center\"><font color=\"#FFFFFF\" face=\"Arial\" size=\"4\"><b>Sales Guard CB Help
      (<a href=\"javascript: window.close();\"><font face=\"Arial\" COLOR=\"#FFFFFF\" size=\"2\">close</font></a>)</b></font>
    </td>
  </tr>
  <tr bgcolor=\"#E5E5E5\">
    <td align=\"left\" width=\"100%\">$display_form
    
    </td>
  </tr>
</table>
<center><a href=\"javascript: window.close();\"><font face=\"Arial\" size=\"2\">close window</font></a></center>

</body>
</html>
";
?>