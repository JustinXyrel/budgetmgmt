<?
//##################################################################################
//SALES GUARD CB LOG UTILITY
//SGCB_LOG.PHP 
//
//
//March 21, 2002
//Software Programs, Inc.  Copyright 2002 - 2003. - Houston, TX USA - All rights reserved.
//www.software-programs.net
//
//License:	Unlimited installations permitted.  Product modifications allowed.  
//			Redistribution prohibited without written approval. 
//
//##################################################################################
//
//REQUIREMENTS: Apache, PHP4

//SETTING VARIABLES ##################################################

$today = date("j-M-Y H:i:s");


$maintitle = "View Log";


session_start();
//prepare globals for handling
$session_array_sgcb = urldecode($session_array_sgcb);
$session_array_sgcb = unserialize($session_array_sgcb);
//prepare globals for handling end

$authorized_user = $session_array_sgcb[authorized_user];
$install_dir = $session_array_sgcb[install_dir];
$sgcb_url = $session_array_sgcb[sgcb_url];
$backup_dir = $session_array_sgcb[backup_dir];
$config_file = $session_array_sgcb[config_file];
$users_file = $session_array_sgcb[users_file];
$products_file = $session_array_sgcb[products_file];
$log_file = $session_array_sgcb[log_file];
$sysadmin = $session_array_sgcb[sysadmin];
$sysadminemail = $session_array_sgcb[sysadminemail];


$sec_dir_info = $session_array_sgcb[sec_dir_info];



$text_color=$session_array_sgcb[text_color];
$current_user_color=$session_array_sgcb[current_user_color];
$title_color = $session_array_sgcb[title_color];
$bg_color = $session_array_sgcb[bg_color];
$alt_bg_color = $session_array_sgcb[alt_bg_color];
$alt_text_color = $session_array_sgcb[alt_text_color];
$msgcb_bg_color = $session_array_sgcb[msgcb_bg_color];
$title_bg_color = $session_array_sgcb[title_bg_color];
$special_text_color = $session_array_sgcb[special_text_color];

//Preparing globals to leave script
if($session_array_sgcb){
	$session_array_sgcb = serialize($session_array_sgcb);
	$session_array_sgcb = urlencode($session_array_sgcb);
}

if (session_status() == PHP_SESSION_NONE) {
    session_start();
}
$_SESSION['session_array_sgcb'] =  $session_array_sgcb;
//session_register('session_array_sgcb');
//Preparing globals to leave script end

//######################## SETTING VARIABLES END #####################


//SECURITY CHECK - RUN LOGIN PAGE IF USER IS NOT AUTHORIZED
if($authorized_user != "admin"){
	

	//Redirect to login form
	header("Location: sgcb.php");
	exit;
	

}//SECURITY CHECK - RUN LOGIN PAGE IF USER IS NOT AUTHORIZED END

//DISPLAY LOG IN DESIRED FORMAT
else{

	//Read log file first if exists

	if(file_exists($log_file)){
		$fd = fopen ($log_file, "r");
		if($fd){$log_info = fread($fd, filesize($log_file));}
		fclose($fd);
	}
	//Read log file first if exists end

	
	//Disect $log_info (if exists) according to given instructions
	if($log_info){
		
		//Retrieving product description
		if($log_id == "pdescr"){

			$maintitle = "Product Information";
			
			$log_pid = urldecode($log_pid);

			//First read products file if exists
			if(file_exists($products_file)){
				$fd = fopen ($products_file, "r");
				if($fd){$products_info = fread($fd, filesize($products_file));}
				fclose($fd);
			}

			unset($products_arr);
			$products_arr=explode("\n",$products_info);
			
			
			foreach($products_arr as $key=>$val){
				
				if($log_pid){

					unset($tmp_val_arr);
					$tmp_val_arr = explode("\t",$val);

					//Product storage format: pid <tab> expiration  <tab> description <tab> URL
					if($log_pid == $tmp_val_arr[0]){
						$display = "yes";
						$pid_disp = $tmp_val_arr[0];
						$pexp_disp = $tmp_val_arr[1];
						$pdescr_disp = $tmp_val_arr[2];
						$purl_disp = $tmp_val_arr[3];
					}

				}//log_pid not empty end
			}//foreach end

			if($display){
				$display_form = "
					<table width=\"100%\">
					<tr bgcolor=\"$title_bg_color\">
						<td colspan=\"2\" align=\"center\"><FONT SIZE=\"2\" COLOR=\"$title_color\" FACE=\"Arial\"><B>$maintitle</B>&nbsp;&nbsp;(<a href=\"javascript: window.close();\"><font face=\"Arial\" COLOR=\"$title_color\" size=\"2\">close</font></a>)</FONT></td>
					</tr>
					
					<tr>
						<td valign=\"top\" align=\"left\"><FONT SIZE=\"2\" COLOR=\"$text_color\" FACE=\"Arial\"><B>Product ID:</B></FONT></td>
						<td valign=\"top\" align=\"left\"><FONT SIZE=\"2\" COLOR=\"$alt_text_color\" FACE=\"Arial\">$pid_disp</FONT></td>
					</tr>
					<tr>
						<td valign=\"top\" align=\"left\"><FONT SIZE=\"2\" COLOR=\"$text_color\" FACE=\"Arial\"><B>Expires in:</B></FONT></td>
						<td valign=\"top\" align=\"left\"><FONT SIZE=\"2\" COLOR=\"$alt_text_color\" FACE=\"Arial\">$pexp_disp days</FONT></td>
					</tr>
					<tr>
						<td valign=\"top\" align=\"left\"><FONT SIZE=\"2\" COLOR=\"$text_color\" FACE=\"Arial\"><B>Description:</B></FONT></td>
						<td valign=\"top\" align=\"left\"><FONT SIZE=\"2\" COLOR=\"$alt_text_color\" FACE=\"Arial\">$pdescr_disp</FONT></td>
					</tr>
					<tr>
						<td valign=\"top\" align=\"left\"><FONT SIZE=\"2\" COLOR=\"$text_color\" FACE=\"Arial\"><B>URL:</B></FONT></td>
						<td valign=\"top\" align=\"left\"><a href=\"$purl_disp\" target=_blank><FONT SIZE=\"2\" FACE=\"Arial\">$purl_disp</FONT></a></td>
					</tr>
					</table>	
				";
			} else {
				$display_form = "<BR><BR><p align=\"center\"><b><font face=\"Arial\" size=\"2\" color=\"$special_text_color\">PRODUCT DISCONTINUED</font></b></p>";
			}


		}//Retrieving product description end

		//##############
		//##############

		//Creating master email list
		else if($log_id == "master"){
			
			$maintitle = "Master E-mail List";

			unset($log_info_arr);
			$log_info_arr = explode("\n",$log_info);
			//log_info_arr exists
			if($log_info_arr){
				foreach($log_info_arr as $key=>$val){
					//if $val not empty
					if($val){
						unset($tmp_val_arr);
						$tmp_val_arr = explode("\t",$val);
						
						$ml_key = $tmp_val_arr[2];
						$master_list_arr[$ml_key] =$ml_key;
						
					} //if $val not empty end
				}//for end

			
			}//log_info_arr exists end 
				
			$master_list = implode(", ",$master_list_arr); 

			$display_form="<table width=\"100%\">
							<tr bgcolor=\"$title_bg_color\">
								<td align=\"center\"><FONT SIZE=\"2\" COLOR=\"$title_color\" FACE=\"Arial\"><B>$maintitle</B>&nbsp;&nbsp;(<a href=\"javascript: window.close();\"><font face=\"Arial\" COLOR=\"$title_color\" size=\"2\">close</font></a>)</FONT></td>
							</tr>
							
							<tr >
								<td align=\"left\"><FONT SIZE=\"2\" COLOR=\"$alt_text_color\" FACE=\"Arial\">$master_list</FONT></td>
							</tr>
							</table>
								<hr>
							";
		} 
		//Creating master email list end

		//##############
		//##############

		//Creating email lists by products
		else if($log_id == "product"){
			
			$maintitle = "E-mail Lists By Product";

			unset($log_info_arr);
			$log_info_arr = explode("\n",$log_info);
			//log_info_arr exists
			if($log_info_arr){
				foreach($log_info_arr as $key=>$val){
					//if $val not empty
					if($val){
						unset($tmp_val_arr);
						$tmp_val_arr = explode("\t",$val);

						$prod_key = $tmp_val_arr[3];
						if(!eregi("$tmp_val_arr[2]",$mail_list_arr[$prod_key])){
							$mail_list_arr[$prod_key] .="$tmp_val_arr[2], ";
						}
						$prod_key="";
						
					} //if $val not empty end
				}//for end

				foreach($mail_list_arr as $key=>$val){
					//if $val not empty
					if($val){
						
						$val_disp = substr($val,0,strlen($val)-2);

						if($curr_bg_color != $alt_bg_color){$curr_bg_color = $alt_bg_color;}
						else {$curr_bg_color = $bg_color;}
						
						$log_pid = $key;
						urlencode($log_pid);

						$log_info_disp .= "
						<tr bgcolor=\"$curr_bg_color\">
							<td colspan=\"2\" align=\"left\"><a href=\"javascript: sgcb_pdescr=window.open('$install_dir/sgcb_log.php?log_id=pdescr&log_pid=$log_pid','sgcb_pdescr','width=400,height=150,toolbar=no,scrollbars=yes, resizable=no,top=60,left=280');sgcb_pdescr.focus();void('');\"><FONT SIZE=\"2\" COLOR=\"$text_color\" FACE=\"Arial\">$key</FONT></a><br>
							<FONT SIZE=\"2\" COLOR=\"$alt_text_color\" FACE=\"Arial\">$val_disp</FONT></td>
							
						</tr>";
					} //if $val not empty end
				}//for end
			}//log_info_arr exists end 

			$display_form="<table width=\"100%\">
							<tr bgcolor=\"$title_bg_color\">
								<td colspan=\"2\" align=\"center\"><FONT SIZE=\"2\" COLOR=\"$title_color\" FACE=\"Arial\"><B>$maintitle</B>&nbsp;&nbsp;(<a href=\"javascript: window.close();\"><font face=\"Arial\" COLOR=\"$title_color\" size=\"2\">close</font></a>)</FONT></td>
							</tr>
							
							$log_info_disp
							</table>
								<hr>
							";
		} 
		//Creating email lists by products end

		//##############
		//##############

		//Default display is by purchase time
		else {
			
			unset($log_info_arr);
			$log_info_arr = explode("\n",$log_info);
			//log_info_arr exists
			if($log_info_arr){
				foreach($log_info_arr as $key=>$val){
					//if $val not empty
					if($val){
						unset($tmp_val_arr);
						$tmp_val_arr = explode("\t",$val);
						
						if($curr_bg_color != $alt_bg_color){$curr_bg_color = $alt_bg_color;}
						else {$curr_bg_color = $bg_color;}

						$log_pid = $tmp_val_arr[3];
						urlencode($log_pid);

						$log_info_disp .= "
						<tr bgcolor=\"$curr_bg_color\">
							<td align=\"center\"><FONT SIZE=\"2\" COLOR=\"$alt_text_color\" FACE=\"Arial\">$tmp_val_arr[0]</FONT></td>
							<td align=\"center\"><FONT SIZE=\"2\" COLOR=\"$alt_text_color\" FACE=\"Arial\">$tmp_val_arr[1]</FONT></td>
							<td align=\"center\"><a href=\"mailto:$tmp_val_arr[2]\"><FONT SIZE=\"2\"  FACE=\"Arial\">$tmp_val_arr[2]</FONT></a></td>
							<td align=\"center\"><a href=\"javascript: sgcb_pdescr=window.open('$install_dir/sgcb_log.php?log_id=pdescr&log_pid=$log_pid','sgcb_pdescr','width=400,height=150,toolbar=no,scrollbars=yes, resizable=no,top=60,left=280');sgcb_pdescr.focus();void('');\"><FONT SIZE=\"2\" COLOR=\"$alt_text_color\" FACE=\"Arial\">$tmp_val_arr[3]</FONT></a>
							</td>
						</tr>";
					} //if $val not empty end
				}//for end
			}//log_info_arr exists end 


			$display_form="<table width=\"100%\">
							<tr bgcolor=\"$title_bg_color\">
								<td colspan=\"4\" align=\"center\"><FONT SIZE=\"2\" COLOR=\"$title_color\" FACE=\"Arial\"><B>$maintitle</B>&nbsp;&nbsp;(<a href=\"javascript: window.close();\"><font face=\"Arial\" COLOR=\"$title_color\" size=\"2\">close</font></a>)</FONT></td>
							</tr>
							<tr>
								<td align=\"center\"><FONT SIZE=\"2\" COLOR=\"$text_color\" FACE=\"Arial\"><B>Purchase Date</B></FONT></td>
								<td align=\"center\"><FONT SIZE=\"2\" COLOR=\"$text_color\" FACE=\"Arial\"><B>Name</B></FONT></td>
								<td align=\"center\"><FONT SIZE=\"2\" COLOR=\"$text_color\" FACE=\"Arial\"><B>Email</B></FONT></td>
								<td align=\"center\"><FONT SIZE=\"2\" COLOR=\"$text_color\" FACE=\"Arial\"><B>Product</B></FONT></td>
							</tr>
							$log_info_disp
							</table>
								<hr>
							";

		}//Default display is by purchase time end
	
	}//Disect $log_info (if exists) according to given instructions end

	//Display empty log sign
	else{
		$display_form="<BR><BR><p align=\"center\"><b><font face=\"Arial\" size=\"2\" color=\"$special_text_color\">CAN NOT DISPLAY LOG OR NO RECORDS EXISTS</font></b></p>";

	}//Display empty log sign end
	
	echo "
	<html>
	<head>
	<title>$maintitle</title>
	</head>

	<body bgcolor=\"$bg_color\">	

	$display_form

	<CENTER><a href=\"javascript: window.close();\"><font face=\"Arial\" size=\"2\">close window</font></a></CENTER>

	</body>
	</html>
	";
}//DISPLAY LOG IN DESIRED FORMAT END
?>